return function(api)
	function api.VanillaMode(self, mode)
		api.IsVanillaMode = mode
	end

	function api.OverrideText(self, name, alias)
		api.tooltip.assignOverride(name, alias)
		return self
	end
	function api.AddCategory(self, Name, Description, EditorAvailable, Icon)
		local Category = {
			Enabled = true;
			Name = Name;
			Description = Description;
			EditorAvailable = EditorAvailable;
			IconName = Icon;
			Icon = love.graphics.newImage(Icon .. ".png");
			Items = {};
		}

		function Category.AddItem(self, ItemName, ItemDescription, EditorLocked)
			local Item = {
				Enabled = true;
				Name = ItemName;
				Alias = nil;
				Description = ItemDescription;
				EditorAvailable = not EditorLocked;
				VanillaItem = EdTweaks.IsVanillaMode;
			}

			function Item.SetAlias(self, Alias)
				self.Alias = Alias
				return self
			end
			function Item.GetAlias(self)
				return self.Alias
			end

			table.insert(self.Items, Item)
			return Item
		end

		table.insert(api.Categories, Category)
		return Category
	end
	function api.GetCategory(self, CategoryName)
		for _,Category in pairs(api.Categories) do
			if Category.Name == CategoryName then
				return Category
			end
		end
	end

	function api.RegisterImage(self, imagename, index, isVanilla, ImageData)
		local Image = {
			Vanilla = isVanilla;
			Name = imagename;
			Image = ImageData;
			Index = index;
		}
		if isVanilla then
			Image.ImagePath = "textures/" .. imagename;
		end
		table.insert(api.Images, Image)
		return Image
	end
	function api.GetRegisteredIcon(imagename)
		for _,ImageData in ipairs(EdTweaks.Images) do
			if ImageData.Name == imagename then
				return ImageData
			end
		end
	end

	local Uns
	function api.AllModdedContentCategory()
		if api.AllExtraCategoryEnabled then
			Uns = Uns or EdTweaks:AddCategory("Modded", "All Modded Content", true, "textures/ccwgenerator")
		end
		return Uns
	end

	function api.RegisterBankName(n, AssetName)
		local bank = setmetatable({
			name=n;
			AssetName = AssetName;
		}, {
			__newindex = function(self, prop, value)
				if prop == 'AssetName' then
					bank.image = assert(api.Assets[value], "Attempt to switch ImageBank entry " ..n.. " to a new asset, while the asset does not exist for name: " ..tostring(value))
				end
				rawset(self, prop, value)
			end;
		})
		if AssetName then
			bank.image = api.Assets[AssetName]
		end
		return bank
	end
end
