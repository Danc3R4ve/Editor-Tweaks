return function(api)
	-- if debugging is enabled, draw last key pressed
	DrawOperation:Bind("Debug_Draw", function()
		if debug_lastkeypres then
			local r,g,b,a = love.graphics.getColor()
			love.graphics.setColor(1,1,1,1)
			love.graphics.printf(debug_lastkeypres, 25,25, 99999, 'left', 0, 1,1)
			love.graphics.setColor(r,g,b,a)
		end
	end)
	-- mod credits
	love.window.setIcon(api.Assets.ico)
	love.window.setTitle("Editor Tweaks " ..api.Version.. " [CelLuAPI]")
	api.delay(0.04, function()
		love.window.setTitle("Editor Tweaks " ..api.Version.. " [CelLuAPI]")
	end)
	DrawOperation:Bind("ModDisplay", function()
		love.graphics.setFont(api.Fonts.Sax20)
		love.graphics.setColor(0.66,0.66,0.66,0.2)
		--love.graphics.printf("Editor Tweaks " ..api.Version, 20,20, 999999, 'left', 0, 1,1, 0,0)
	end)
end
