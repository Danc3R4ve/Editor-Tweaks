return function(api)
	local function lerp(x,y,n)
		return x+((y-x)*n)
	end
	local function elasticin(x)
		x=math.min(1,math.max(0,x))
		return 2*x*(x-.5)
	end
	local function elasticout(x)
		x=math.min(1,math.max(0,x))
			x=x-.5
		return 1-(2*x*(x-.5))
	end
	api.dosmoothdraw = function(initrotation, enabled, drawable, p1,p2, a1,a2, t, r, sx,sy,...)
		-- draw smoothly, with a couple additional parameters of its spawning
		local new = api.drawables[drawable] ~= nil
		api.drawables[drawable] = api.drawables[drawable] or {
			delta = 0;
			targetAlpha = 1;
			alpha = 0;
			x = 0;
			smoothingfunction = elasticout;
			initTimer = api.timer;
			lastr = 0;
			smoothtime = t; -- how much time when a button spawns is it in fading?
			p = {x=x;y=y;}; -- on-screen position
			s = {
				w = drawable:getWidth();
				h = drawable:getHeight();
				w2 = drawable:getWidth()/2;
				h2 = drawable:getHeight()/2;
			}; -- on-screen size
		}

		local drawbank = api.drawables[drawable]
		assert(drawbank.initTimer, "initTimer not set. Is new timer? " ..tostring(new))
		if enabled ~= drawbank.enabled then
			drawbank.enabled = enabled
			-- set alpha to new, what it currently is
			drawbank.alpha = lerp(drawbank.alpha, drawbank.targetAlpha, drawbank.delta)
			drawbank.initTimer = api.timer
			drawbank.enabled = enabled
			drawbank.delta = 0
			drawbank.x = 0
			if drawbank.enabled then
				drawbank.targetAlpha = a2
			else
				drawbank.targetAlpha = a1
			end
		end
		drawbank.delta = math.min(1, (api.timer - drawbank.initTimer) / drawbank.smoothtime)
		drawbank.x = drawbank.smoothingfunction(drawbank.delta)
		if enabled then
			drawbank.p.x = lerp(p1.x, p2.x, drawbank.x)
			drawbank.p.y = lerp(p1.y, p2.y, drawbank.x)
		else
			drawbank.p.x = lerp(p2.x, p1.x, drawbank.x)
			drawbank.p.y = lerp(p2.y, p1.y, drawbank.x)
		end
		local ratio = drawbank.delta / drawbank.smoothtime
		local r,g,b,a = love.graphics.getColor()
		love.graphics.setColor(r,g,b,lerp(drawbank.alpha, drawbank.targetAlpha, drawbank.delta))
		--love.graphics.print("XY: " ..(drawbank.p.x ..",".. drawbank.p.y)..string.format'\n'.."Delta:"..drawbank.delta.. string.format'\n'.."" ..drawbank.alpha.. " : " ..drawbank.targetAlpha..string.format'\n'.."Timer: " ..math.floor(api.timer - drawbank.initTimer), 100, 100, 0, 1,1)
		love.graphics.draw(drawable,drawbank.p.x,drawbank.p.y,enabled and lerp(0, math.rad(initrotation), drawbank.x) or lerp(0, math.rad(initrotation), drawbank.x),sx,sy,...)
		love.graphics.setColor(r,g,b,a)
	end
	function api.line( ox, oy, ex, ey, callback, ... )
		local dx = math.abs( ex - ox )
		local dy = math.abs( ey - oy ) * -1

		local sx = ox < ex and 1 or -1
		local sy = oy < ey and 1 or -1
		local err = dx + dy

		local counter = 0
		while true do
			-- If a callback has been provided, it controls wether the line
			-- algorithm should proceed or not.
			if callback then
				local continue = callback( ox, oy, counter, ... )
				if not continue then
					return false, counter
				end
			end

			counter = counter + 1

			if ox == ex and oy == ey then
				return true, counter
			end

			local tmpErr = 2 * err
			if tmpErr > dy then
				err = err + dy
				ox = ox + sx
			end
			if tmpErr < dx then
				err = err + dx
				oy = oy + sy
			end
		end
	end
	function api.GetFills(x,y, referenceTile, fills, ox,oy)
		ox, oy = ox or x, oy or y
		local dist = (x - ox)^2 + (y - oy)^2
		if dist > 35^2 then return end -- stack overflow prevention measures
		fills = fills or {}
		for ly = y-1, y+1 do
			for lx = x-1, x+1 do
				if (lx~=x) or (ly~=y) then
					if not fills[ly] then
						fills[ly] = {}
					end
					if (not fills[ly][lx])
						and (lx >= 1) and (lx <= width)
						and (ly >= 1) and (ly <= height)
						and (cells[ly][lx].ctype == referenceTile.ctype)
						and ((cells[ly][lx].rot == referenceTile.rot) or (referenceTile.ctype == 0))
					then
						fills[ly][lx] = true
						api.GetFills(lx,ly, referenceTile, fills, ox,oy)
					end
				end
			end
		end
	end
	function api.ETweaksInternalButton(label, shortcut, x,y, x2,y2, a1,a2, r, i, scale, title, text, fn)
		scale = scale or 1
		local cl2 = love.graphics.newImage(api.EditorButtonPath)
		local cl3
		if i.IconName then
			cl3 = love.graphics.newImage(i.IconName.. ".png")
		elseif i.VanillaItem then
			cl3 = love.graphics.newImage("textures/" ..i.Name.. ".png")
		else
			local Ic = assert( api.GetRegisteredIcon(i.Name) , "Invalid Icon for item: \"" .. tostring(i.Name) .. "\"")
			if Ic and Ic.ImagePath then
				cl3 = love.graphics.newImage(Ic.ImagePath)
			else
				cl3 = Ic.Image
			end
		end
		local imscale = 60 / ((cl3:getWidth() + cl3:getHeight()) / 2)
		local kxscale = (cl3:getWidth() / 2)
		local dx,dy = 0,0
		local green
		local mousein, mscale = false, 0
		api.drawables[cl2] = nil
		api.drawables[cl3] = nil
		local BData = {
			Data = {
				Pos1={x=x;y=y;};
				Pos2={x=x2;y=y2;};
				x=0; y=0;
				paddingscale = 0.75;
				i=cl3;
			};
			Draw = function(self)
				local i,Pos1,Pos2,paddingscale = self.Data.i,self.Data.Pos1,self.Data.Pos2,self.Data.paddingscale
				love.graphics.setColor(1,1,1,1)
				api.dosmoothdraw(0, true, cl2, Pos1, Pos2, 0.5,1, 0.2, 0, scale,scale, 30,30)
				local t = api.drawables[cl2]
				local mx, my = love.mouse.getX(), love.mouse.getY()
				if (mx >= t.p.x - t.s.w2) and (mx <= t.p.x + t.s.w2) and (my >= t.p.y - t.s.h2) and (my <= t.p.y + t.s.h2) then
					mousein = true
					mscale = mscale + delta
				else
					mousein = false
					mscale = 0
				end
				if i then
					local _ms = (math.cos(mscale * math.pi * 4) + 12)/12
					api.dosmoothdraw(currentrot * 90, true, self.Data.i, Pos1, Pos2, 0.5,1, 0.2, currentrot * 90, _ms * imscale * scale * paddingscale,_ms * imscale * scale * paddingscale, kxscale,kxscale, kx, ky)
				end
				love.graphics.setColor(1,1,1,1)
				if t.p.x==Pos2.x then -- is fully rendered
					if shortcut then
						local oldfnt = love.graphics.getFont()
						love.graphics.setFont(api.Fonts.Sax)
						love.graphics.setColor(0,0,0,.5)
						love.graphics.printf(shortcut, Pos2.x-t.s.w2+2,Pos2.y-t.s.h2+2, 999999, 'left', 0, 1,1)
						love.graphics.printf(shortcut, Pos2.x-t.s.w2-2,Pos2.y-t.s.h2+2, 999999, 'left', 0, 1,1)
						love.graphics.printf(shortcut, Pos2.x-t.s.w2+2,Pos2.y-t.s.h2-2, 999999, 'left', 0, 1,1)
						love.graphics.printf(shortcut, Pos2.x-t.s.w2-2,Pos2.y-t.s.h2-2, 999999, 'left', 0, 1,1)
						love.graphics.setColor(1,1,1,1)
						love.graphics.printf(shortcut, Pos2.x-t.s.w2,Pos2.y-t.s.h2, 999999, 'left', 0, 1,1)
						love.graphics.setFont(oldfnt)
					end
				end
				if mousein then
					if t.p.x == Pos2.x then -- prevent buggy display
						if #api.SubMenuButtonList>0 then
							api.tooltip.Draw(title, text, {x=t.p.x+70})
						else
							api.tooltip.Draw(title, text, {x=t.p.x+10})
						end
					end
				end
			end;
		}
		local btn = DrawOperation:Bind("Buttons::" ..label, function()
			BData:Draw()
		end)
		MPressOperation:Bind("Hitbox::" ..label, function(x,y,b, istouch, presses)
			local t = api.drawables[cl2]
			local mx, my = love.mouse.getX(), love.mouse.getY()
			if t and (b==1) then
				if (mx >= t.p.x - t.s.w2) and (mx <= t.p.x + t.s.w2) and (my >= t.p.y - t.s.h2) and (my <= t.p.y + t.s.h2) then
					fn(BData)
					placecells = false
				end
			end
		end)
		return BData, BData.Data.i
	end
end
