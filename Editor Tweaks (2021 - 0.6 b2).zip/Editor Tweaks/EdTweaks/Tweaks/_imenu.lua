return function(api)
	local Pos1,Pos2 = {x=0,y=0},{x=0;y=0}
	local EditIndex
	-- animates the plus with dosmoothdraw
	local btn = DrawOperation:Bind("Buttons::Plus", function()
		local sw,sh = love.graphics.getWidth(), love.graphics.getHeight()
		Pos1.x, Pos1.y = 40, sh-40
		Pos2.x, Pos2.y = 80, sh-60
		api.dosmoothdraw(0, api.enabled, api.ImageBank.button.image, Pos1, Pos2, 0.5,1, 0.2, 0, 1,1, 30,30)
		api.dosmoothdraw(180, api.enabled, api.ImageBank.plus.image, Pos1, Pos2, 0.5,1, 0.3, 0, 1,1, 30,30)
	end)
	-- removes the existing menu buttons from the arrays
	function api.RemoveMenuButtons(fix)
		if not (fix==2) then
			for i = #api.MenuButtonList, 1, -1 do
				table.remove(api.MenuButtonList,i)
			end
		end
		for i = #api.SubMenuButtonList, 1, -1 do
			table.remove(api.SubMenuButtonList,i)
		end
	end

	--/ UPDATE MAIN MENU BUTTONS' POSITIONS
	UpdateOperation:Bind("Hitbox::MenuAdjustment-1", function(dt)
		local kbmode = api.drawConfig.KBMode
		if not kbmode then
			local sh = love.graphics.getHeight()
			local my = love.mouse.getY()
			local mx = love.mouse.getX()
			local padding = 120
			local diff = math.min(0, sh - ((#api.MenuButtonList * 66) + padding))
			for _,button in pairs(api.MenuButtonList) do
				local pos = button[1].Data.Pos2
				if (mx < pos.x + 33) or (not button[4]) then
					button[4] = true -- make sure to initialize the first position
					local ind = (#api.MenuButtonList-button[2])+1
					pos.y = math.floor(0.5+((ind*66) + (padding / 4) + lerp(0, diff, my/sh)))
				end
			end
		else
			if not UpdateOperation:FindBindByLabel("Hitbox::EditorTweaks/SubMenuButton") then
				local sh = love.graphics.getHeight()
				local mx = love.mouse.getX()
				local padding = 120
				local diff = math.min(0, sh - ((#api.MenuButtonList * 66) + padding))
				for _,button in pairs(api.MenuButtonList) do
					local pos = button[1].Data.Pos2
					if (not button[4]) then
						--button[4] = true
						local ind = (#api.MenuButtonList-button[2]) + 1
						pos.y = math.floor(0.5 + (ind * 66))
					end
				end
			else
				local sh = love.graphics.getHeight()
				local mx = love.mouse.getX()
				local padding = 120
				local diff = math.min(0, sh - ((#api.MenuButtonList * 66) + padding))
				for _,button in pairs(api.SubMenuButtonList) do
					local pos = button[1].Data.Pos2
					if (not button[4]) then
						--button[4] = true
						local ind = (#api.MenuButtonList-button[2]) + 1
						pos.y = math.floor(0.5 + (ind * 66))
					end
				end
			end
		end
	end)
	KPressOperation:Bind("Hitbox::MenuAdjustment-1", function(key)
		if api.drawConfig.KBMode then
			local lastItem,nextItem, lastPage,nextPage = api.KeyMap.Down, api.KeyMap.Up,
								api.KeyMap.PageDown, api.KeyMap.PageUp
			for i,k in ipairs(lastItem) do
				if k==key then
					if api.selectionmenu > 1 then
						api.selectionmenu = math.max(1, api.selectionmenu - 1)
					else
						api.selectionpage, api.selectionmenu = api.selectionpage - 1, 1
					end
				end
			end
			for i,k in ipairs(nextItem) do
				if k==key then
					if api.selectionmenu < 10 then
						api.selectionmenu = math.min(10, api.selectionmenu + 1)
					else
						api.selectionpage, api.selectionmenu = api.selectionpage + 1, 1
					end
				end
			end
		end
	end)
	--/ UPDATE SUB MENU BUTTONS' POSITIONS
	UpdateOperation:Bind("Hitbox::MenuAdjustment-2", function(dt)
		local kbmode = api.drawConfig.KBMode
		if not kbmode then
			local sh = love.graphics.getHeight()
			local my = love.mouse.getY()
			local mx = love.mouse.getX()
			local padding = 120
			local diff = math.min(0, sh - ((#api.SubMenuButtonList * 66) + padding))
			for _,button in pairs(api.SubMenuButtonList) do
				local pos = button[1].Data.Pos2
				if (mx >= pos.x - 33) or (not button[4]) then
					button[4] = true -- make sure to initialize the first position
					local ind = (#api.SubMenuButtonList-button[2])+1
					pos.y = math.floor(0.5+((ind*66) + (padding / 4) + lerp(0, diff, my/sh)))
				end
			end
		else
		end
	end)

	-- removes sub menu buttons
	function api.ClearSubMenuButtons(...)
		DrawOperation:Unbind("Buttons::EditorTweaks/SubMenuButton")
		MPressOperation:Unbind("Hitbox::EditorTweaks/SubMenuButton")
		EditIndex = nil
		api.RemoveMenuButtons(...)
	end

	function api.SetCursorItem(ItemData, i)
		local t = api.drawables[api.ImageBank.button.image]
		local sh = love.graphics.getHeight()
		local RegisteredIndex = EdTweaks.GetRegisteredIcon(ItemData.Name)
		if RegisteredIndex then
			currentstate = RegisteredIndex.Index
		else
			error("No valid item index was designated to the category's items!")
		end
		-- Why is this complicated? Because we are restructuring its end points.
		-- This requires resetting the deltas and everything during transition
		-- Or establishing a proper Object tweening system. I opted for the former.
		for _,button in pairs(api.MenuButtonList) do
			api.drawables[button[3] ].initTimer = api.timer
			local Pos1,Pos2 = button[1].Data.Pos1,button[1].Data.Pos2
			button[1].Data.Pos1 = {x=Pos2.x, y=Pos2.y}
			button[1].Data.Pos2 = {x=-65, y=sh/2}
		end
		for _,button in pairs(api.SubMenuButtonList) do
			api.drawables[button[3] ].initTimer = api.timer
			local Pos1,Pos2 = button[1].Data.Pos1,button[1].Data.Pos2
			button[1].Data.Pos1 = {x=Pos2.x, y=Pos2.y}
			button[1].Data.Pos2 = {x=-65, y=sh/2}
		end
		api.RemoveMenuButtons()
		api.ToggleEnabledState(true)
		placecells = false
	end

	function api.MenuButton(EditData, _EditIndex)
		local t = api.drawables[api.ImageBank.button.image]
		local sh = love.graphics.getHeight()
		if EditIndex == _EditIndex then api.ClearSubMenuButtons() return end
		--/ Delete any old buttons
		api.ClearSubMenuButtons(2)
		--/ Spawn new ones in
		--table.sort(EditData, function(n1,n2) return n1.Name < n2.Name end)
		EditIndex = _EditIndex
		for i = #api.MenuButtonList, 1, -1 do
			local button = api.MenuButtonList[i]
			if button.Data then
				api.drawables[button.Data.i] = nil
				table.remove(api.MenuButtonList, i)
			end
		end
		for i,ItemData in ipairs(EditData) do
			local ItemName = ItemData:GetAlias() or ItemData.Name or "undefined"
			local title, desc = ItemName:sub(1,1):upper() .. ItemName:sub(2), ItemData.Description
			local button2, boundimage = api.ETweaksInternalButton("EditorTweaks/SubMenuButton", (i<=10 and tostring(i%10) or nil), t.p.x,t.p.y, 216,sh - (60*i), 0,1, 0, ItemData, 1, title, desc, function(BData)
				api.SetCursorItem(ItemData, i)
			end)
			table.insert(api.SubMenuButtonList,{button2,i,boundimage})
		end
		--/ Nope, don't place anything yet!
		placecells = false
	end

	local tools = {
		freeDraw, lineDraw, squareDraw, circleDraw
	}
	local ltools = {
		--fuzzy, filled, orientation, kbmode, up, down, pageup, pagedown, select
	}
	local scale = (60 / 20) / 2
	function api.MakeDrawTool(label, drawmode, toolname, switch, scale, BY, shortcuts)
		local Assets = api.Assets
		local s = api.drawMode == drawmode
		tools[toolname] = api.EdTweaksButton(label, 50 + (switch*22*scale),BY, Assets[drawmode:sub(1,1):upper()..drawmode:sub(2)], shortcuts)
			:Rescale(scale)
			:Recolor(s and 0 or 255, 255, s and 0 or 255)
		tools[toolname]:ConnectEvent('mpress', function(x,y,b, istouch)
			api.drawMode = drawmode
			for tool, toolButton in pairs(tools) do
				toolButton.T = {r=255,g=255,b=255}
			end
			tools[toolname].T = {r=0,g=255,b=0}
		end)
		switch = (switch + 1) % 2
		if (switch == 0) then BY = BY - (22 * scale) end
		return switch, BY
	end
	local function __selected_default(self)
		return self.selected
	end
	local function __removekb(self)
		local s = {'Up', 'Down', 'PageUp', 'PageDown', 'Select'}
		for tool, toolButton in pairs(ltools) do
			for i = 1, #s do
				if s[i] == tool then
					toolButton:Remove()
					ltools[tool] = nil
				end
			end
		end
	end
	function api.MakeLTools()
		local switch = 0
		local BY = love.graphics.getHeight() - 175
		local Assets = api.Assets
		local km = api.KeyMap
		local make2 = {
			{
				n = "Down";
				d = "Navigate down in the selected menu.";
				i = api.ImageBank.down;
				s = km.Down;
				noclose = true; -- prevents closing of the menu?
				selected = false;
				f1 = function(self, x,y,b)

					return self
				end;
			},
			{
				n = "Up";
				d = "Navigate up in the selected menu.";
				i = api.ImageBank.up;
				s = km.Up;
				noclose = true; -- prevents closing of the menu?
				selected = false;
				f1 = function(self, x,y,b)

					return self
				end;
			},
			{
				n = "PageDown";
				d = "Navigate down a page in the selected menu.";
				i = api.ImageBank.pagedown;
				s = km.PageDown;
				noclose = true; -- prevents closing of the menu?
				selected = false;
				f1 = function(self, x,y,b)

					return self
				end;
			},
			{
				n = "PageUp";
				d = "Navigate up a page in the selected menu.";
				i = api.ImageBank.pageup;
				s = km.PageUp;
				noclose = true; -- prevents closing of the menu?
				selected = false;
				f1 = function(self, x,y,b)

					return self
				end;
			},
			{
				n = "Select";
				d = "Advances the menu or selects the selected submenu item.";
				i = api.ImageBank.select;
				s = km.Select;
				noclose = true; -- prevents closing of the menu?
				selected = false;
				f1 = function(self, x,y,b)

					return self
				end;
			},
		}
		local make = {
			--[[{
				n = "Fuzzy";
				d = "Decides if fill will activate regardless of most visible characteristics.";
				i = api.ImageBank.fuzzy;
				s = km.Fuzzy;
				noclose = true; -- prevents closing of the menu?
				selected = api.drawConfig.isFuzzy or false;
				sl = __selected_default;
				f1 = function(self, x,y,b)
					self.selected = not self.selected
					api.drawConfig.isFuzzy = self.selected
					self.tool.T = self.selected and {r=0,g=255,b=0} or {r=255,g=255,b=255}
					return self
				end;
			},]]
			{
				n = "Filled";
				d = "When drawing squares and circles, decides if it fills them.";
				i = api.ImageBank.filled;
				s = km.Filled;
				noclose = true; -- prevents closing of the menu?
				selected = api.drawConfig.isFilled or false;
				sl = __selected_default;
				f1 = function(self, x,y,b)
					self.selected = not self.selected
					api.drawConfig.isFilled = self.selected
					self.tool.T = self.selected and {r=0,g=255,b=0} or {r=255,g=255,b=255}
					return self
				end;
			},
			{
				n = "Orientation";
				d = "Changes the orientation mode between 'Static', 'Round Robin', 'Random'. They each affect how cells are rotated when you place them.";
				i = api.ImageBank.orientation;
				s = km.Orientation;
				noclose = true; -- prevents closing of the menu?
				selected = false;
				sl = function() return false end;
				f1 = function(self, x,y,b)
					api.orientationMode = (api.orientationMode=='Static' and 'RoundRobin') or
						(api.orientationMode=='RoundRobin' and 'Random') or
						'Static'
					self.i.image = api.Assets[api.orientationMode]
					self.tool:ChangeIcon(self.i.image)
					return self
				end;
			},
			--[[{
				n = "KBMode";
				d = "Uses keyboard instead of mouse to navigate the menu.";
				i = api.ImageBank.kbmode;
				s = km.KBMode;
				noclose = true; -- prevents closing of the menu?
				selected = api.drawConfig.KBMode or false;
				sl = function(self)
					return self.selected, true
				end;
				spawnkb = function(self)
					BY, switch = self.BY or BY, self.switch or switch
					for _,D in pairs(make2) do
						local s = false
						local toolname = D.n
						local label = D.n
						ltools[toolname] = api.EdTweaksButton(label, (50 - (22 * scale)), BY, D.i.image, D.s, D.d, D.noclose)
						ltools[toolname]:Rescale(scale)
						ltools[toolname]:Recolor(s and 0 or 255, 255, s and 0 or 255)
						D.tool = ltools[toolname]
						ltools[toolname]:ConnectEvent('mpress', function(...) D:f1(...) end)
						switch = (switch + 1)
						BY = BY - (22 * scale)
						D.switch, D.BY = switch, BY
					end
				end;
				removekb = __removekb;
				f1 = function(self, x,y,b)
					self.selected = not self.selected
					api.drawConfig.KBMode = self.selected
					self.tool.T = self.selected and {r=0,g=255,b=0} or {r=255,g=255,b=255}
					self[self.selected and 'spawnkb' or 'removekb'](self)
					return self
				end;
			},]]
		}
		--api.orientationMode = "Static"
		for _,D in pairs(make) do
			local s, iskbm = D:sl()
			local toolname = D.n
			local label = D.n
			ltools[toolname] = api.EdTweaksButton(label, (50 - (22 * scale)), BY, D.i.image, D.s, D.d, D.noclose)
			ltools[toolname]:Rescale(scale)
			ltools[toolname]:Recolor(s and 0 or 255, 255, s and 0 or 255)
			D.tool = ltools[toolname]
			ltools[toolname]:ConnectEvent('mpress', function(...) D:f1(...) end)
			switch = (switch + 1)
			BY = BY - (22 * scale)
			D.switch, D.BY = switch, BY
			if iskbm then
				D[D.selected and 'spawnkb' or 'removekb'](D)
			end
		end
	end
	function api.ToggleEnabledState(add_delay)
		local t = api.drawables[api.ImageBank.button.image]
		api.enabled = not api.enabled
		placecells = false
		if api.enabled then
			local cl = love.graphics.newImage(api.EditorButtonPath)
			local sh = love.graphics.getHeight()
			for i,EditData in ipairs(EdTweaks.Categories) do
				local title, desc = EditData.Name:sub(1,1):upper() .. EditData.Name:sub(2), EditData.Description
				local button, boundimage = api.ETweaksInternalButton("EditorTweaks/MenuButton", (i<=10 and tostring(i%10) or nil), t.p.x,t.p.y, 150,sh - (60*i), 0,1, 0, EditData, 1, title, desc, function(BData)
					api.MenuButton(EditData.Items, i)
				end)
				table.insert(api.MenuButtonList,{button,i,boundimage})
				button.i = cl
			end
			--/ Menu buttons
			local BY = love.graphics.getHeight() - 175
			local switch = 0
				for tool, toolButton in pairs(tools) do
					toolButton:Remove()
					tools[tool] = nil
				end
				for tool, toolButton in pairs(ltools) do
					toolButton:Remove()
					ltools[tool] = nil
				end
				local km = api.KeyMap
				local drawMode, toolName = 'free', 'freeDraw'
				switch, BY = api.MakeDrawTool("Free Draw Button", drawMode, toolName, switch, scale, BY, km.Free)
				local drawMode, toolName = 'line', 'lineDraw'
				switch, BY = api.MakeDrawTool("Line Draw Button", drawMode, toolName, switch, scale, BY, km.Line)
				local drawMode, toolName = 'square', 'squareDraw'
				switch, BY = api.MakeDrawTool("Square Draw Button", drawMode, toolName, switch, scale, BY, km.Square)
				local drawMode, toolName = 'circle', 'circleDraw'
				switch, BY = api.MakeDrawTool("Circle Draw Button", drawMode, toolName, switch, scale, BY, km.Circle)
				local drawMode, toolName = 'fill', 'fillDraw'
				switch, BY = api.MakeDrawTool("Fill Button", drawMode, toolName, switch, scale, BY, km.Fill)
				api.MakeLTools()
		elseif add_delay then
			for tool, toolButton in pairs(tools) do
				toolButton:Remove()
				tools[tool] = nil
			end
			for tool, toolButton in pairs(ltools) do
				toolButton:Remove()
				ltools[tool] = nil
			end
			local delay = api.delay
			delay(0.24, function()
				DrawOperation:Unbind("Buttons::EditorTweaks/MenuButton")
				MPressOperation:Unbind("Hitbox::EditorTweaks/MenuButton")
				api.ClearSubMenuButtons()
			end)
		else
			for tool, toolButton in pairs(tools) do
				toolButton:Remove()
				tools[tool] = nil
			end
			for tool, toolButton in pairs(ltools) do
				toolButton:Remove()
				ltools[tool] = nil
			end
			DrawOperation:Unbind("Buttons::EditorTweaks/MenuButton")
			MPressOperation:Unbind("Hitbox::EditorTweaks/MenuButton")
			api.ClearSubMenuButtons()
		end
	end

	MPressOperation:Bind("Hitbox::Plus", function(x,y,b, istouch, presses)
		local t = api.drawables[api.ImageBank.button.image]
		local mx, my = love.mouse.getX(), love.mouse.getY()
		if t and (b==1) then
			if mx >= t.p.x - t.s.w2 and mx <= t.p.x + t.s.w2 and my >= t.p.y - t.s.h2 and mx <= t.p.y + t.s.h2 then
				api.ToggleEnabledState()
			end
		end
	end)

	if api.debugging then
		--/ Show debug information
		debug_lastkeypres = nil
		KPressOperation:Bind("Debug_KeyPresses", function(key, scancode, isrepeat)
			debug_lastkeypres = "Last Keypress: " ..key
		end)
	end
	KPressOperation:Bind("EditorTweaks::KShortcuts-Menu", function(key, scancode, isrepeat)
		if key == "`" then
			api.ToggleEnabledState()
		end
	end)

	do
		local hotbar = {}
		local ctrlheld
		local SelectionKeys = {
			['1']=1; ['2']=2; ['3']=3;
			['4']=4; ['5']=5; ['6']=6;
			['7']=7; ['8']=8; ['9']=9;
			['0']=10;

			['kp1']=1; ['kp2']=2; ['kp3']=3;
			['kp4']=4; ['kp5']=5; ['kp6']=6;
			['kp7']=7; ['kp8']=8; ['kp9']=9;
			['kp0']=10;
		}
		KPressOperation:Bind("EditorTweaks::KShortcuts-MenuSelector", function(key, scancode, isrepeat)
			if SelectionKeys[key] then
				--/ If the key matches one of the indexes
				if api.enabled then
					--/ If the menu is open
					if not MPressOperation:FindBindByLabel("Hitbox::EditorTweaks/SubMenuButton") then
						--/ If a submenu is not summoned yet
						local EditData = EdTweaks.Categories[ SelectionKeys[key] ]
						if EditData then
							EditData = EditData.Items
							-- If the menu has existing summon data, summon the submenu
							api.MenuButton(EditData, SelectionKeys[key])
						end
					elseif EditIndex then
						--/ If a submenu is open, select the submenu item instead
						local EditData = EdTweaks.Categories[ EditIndex ]
						if EditData then
							EditData = EditData.Items
							local sort_key = EditData[ SelectionKeys[key] ]
							if sort_key then
								api.SetCursorItem(sort_key, SelectionKeys[key])
							else
								api.ToggleEnabledState()
							end
						end
					end
				end
			end
		end)
		KReleaseOperation:Bind("EditorTweaks::KShortcuts-MenuSelector-Release", function(key)
			--/ Not yet implemented!
		end)
	end
	btn:Link("Hitbox::Plus")
end
