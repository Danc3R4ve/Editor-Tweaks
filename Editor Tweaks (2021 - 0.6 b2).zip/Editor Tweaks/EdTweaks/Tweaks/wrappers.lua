return function(api)
	do
		--/ Override addcell to add unsorted content
		local oldaddCell = addCell
		function addCell(label, ...)

			local cellID = oldaddCell(label, ...)
			EdTweaks:RegisterImage(label, cellID, nil, tex[cellID]) --:match"^(.+)%.png$" or texture)
			if api.AllModdedContentCategory() then
				api.AllModdedContentCategory():AddItem(label, "Modded item.")
			end
			return cellID
		end
		local B = MPressOperation:FindBindByLabel"Hitbox::Page-Controls"
		if B then
			MPressOperation:Unbind(B.label)
		end
		DrawOperation:Override("Buttons::Controls", function()
			love.graphics.draw(tex[13],715*winxm,475*winym-80*winxm,-math.pi/2,40*winxm/texsize[13].w,40*winxm/texsize[13].h,texsize[13].w)
			love.graphics.draw(tex[13],755*winxm,475*winym-40*winxm,0,40*winxm/texsize[13].w,40*winxm/texsize[13].h)
			love.graphics.draw(tex[13],715*winxm,475*winym,math.pi/2,40*winxm/texsize[13].w,40*winxm/texsize[13].h,0,texsize[13].h)
			love.graphics.draw(tex[13],675*winxm,475*winym-40*winxm,math.pi,40*winxm/texsize[13].w,40*winxm/texsize[13].h,texsize[13].w,texsize[13].h)
			love.graphics.draw(tex[9],755*winxm,475*winym-80*winxm,0,40*winxm/texsize[9].w,40*winxm/texsize[9].h)
			love.graphics.draw(tex[8],675*winxm,475*winym-80*winxm,0,40*winxm/texsize[8].w,40*winxm/texsize[8].h)
			-- love.graphics.draw(tex[1],755*winxm,475*winym,0,40*winxm/texsize[1].w,40*winxm/texsize[1].h)
			-- love.graphics.draw(tex[1],675*winxm,475*winym,math.pi,40*winxm/texsize[1].w,40*winxm/texsize[1].h,texsize[1].w,texsize[1].h)
		end)
	end
end
