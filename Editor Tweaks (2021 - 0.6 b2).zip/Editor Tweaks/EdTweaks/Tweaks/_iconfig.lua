return function(api)
	api.drawables = {} -- table containing memory addresses as keys for love2d images and animation data as the values.
	api.enabled = false -- is the menu enabled? do not overwrite this, as there are functions that handle it properly.
	api.kbmode = false -- will the menu respond with keyboard/mouse?
	api.selectionpage = 1
	api.selectionmenu = 1
	api.selectionsubmenu = 1
	api.drawConfig = {
		isFuzzy = false;
		isFilled = true;
		KBMode = false;
	}
	api.orientationMode = "Static"
	api.ImageBank = { -- internal image bank
		button = api.RegisterBankName("button", "Button");
		plus = api.RegisterBankName("plus", "Plus");

		fuzzy = api.RegisterBankName("Fuzzy", "Fuzzy");
		filled = api.RegisterBankName("Filled", "Filled");
		orientation = api.RegisterBankName("Orientation", api.orientationMode);
		kbmode = api.RegisterBankName("KBMode", "KBMode");
		up = api.RegisterBankName("Up", "Up");
		down = api.RegisterBankName("Down", "Down");
		select = api.RegisterBankName("Select", "Select");
 		pageup = api.RegisterBankName("PageUp", "PageUp");
 		pagedown = api.RegisterBankName("PageDown", "PageDown");
	}
	api.Fonts = {} -- font directory for edtweaks
	api.Fonts.Sax = love.graphics.newFont(api.dir.. "saxmono.ttf", 32) -- 32-point saxmono font
	api.Fonts.Sax20 = love.graphics.newFont(api.dir.. "saxmono.ttf", 20) -- 20-point saxmono font
	api.MenuButtonList = {} -- list of EdTweaksButton objects
	api.SubMenuButtonList = {} -- list of EdTweakButton objects
end
