return function(api)
	-- ghost tiles animation functionality
	DrawOperation:BindAfter("SelectionSquare", function()
		-- conditions where ghost tiles do not show
			if api.enabled then EdTweaks.Shadowing = false return end
			if inmenu then EdTweaks.Shadowing = false return end
			if selecting then EdTweaks.Shadowing = false return end
			if pasting then EdTweaks.Shadowing = false return end
		-- end
		EdTweaks.Shadowing = true
		local x = math.floor((love.mouse.getX()+offx)/zoom)
		local y = math.floor((love.mouse.getY()+offy)/zoom)
		if x > 0 and y > 0 and x < width-1 and y < height-1 then
			if not tonumber(currentstate) then
				error("Invalid state: " ..tostring(currentstate))
			end
			local theTile = tex[currentstate]
			local w2,h2 = theTile:getWidth()/2, theTile:getHeight()/2
			local scale = zoom/20
			local r,g,b,a = love.graphics.getColor()
			love.graphics.setColor(1,1,1,.5)
			if EdTweaks.Anchor then
				local dm = EdTweaks.drawMode
				local ax,ay = EdTweaks.Anchor.x, EdTweaks.Anchor.y
				if dm == 'free' then
					-- might be some bug, draw regular free operation
					love.graphics.draw(theTile, ((x)*zoom)-offx + (w2 * scale), ((y)*zoom)-offy + (h2 * scale), math.rad(currentrot * 90), scale, scale, w2,h2, kx, ky)
				elseif dm == 'line' then
					api.line( ax,ay, x,y, function(nlx,nly, draw_count)
						love.graphics.draw(theTile, ((nlx)*zoom)-offx + (w2 * scale), ((nly)*zoom)-offy + (h2 * scale), math.rad(currentrot * 90), scale, scale, w2,h2, kx, ky)
						return true
					end)
				elseif dm == 'square' then
					local x1,y1,x2,y2 = math.min(ax,x),math.min(ay,y),math.max(ax,x),math.max(ay,y)
					for nlx = x1, x2 do
						for nly = y1, y2 do
							love.graphics.draw(theTile, ((nlx)*zoom)-offx + (w2 * scale), ((nly)*zoom)-offy + (h2 * scale), math.rad(currentrot * 90), scale, scale, w2,h2, kx, ky)
						end
					end
				elseif dm == 'circle' then
					local x1,y1,x2,y2 = math.min(ax,x),math.min(ay,y),math.max(ax,x),math.max(ay,y)
					for nlx = x1, x2 do
						local xs = (nlx - x1) / math.max(1, x2 - x1)
						for nly = y1, y2 do
							local ys = (nly - y1) / math.max(1, y2 - y1)
							if (((xs - 0.5) ^ 2) + ((ys - 0.5) ^ 2) <= 0.51 ^ 2) or
								(x2-x1<1) or (y2-y1<1) then
								love.graphics.draw(theTile, ((nlx)*zoom)-offx + (w2 * scale), ((nly)*zoom)-offy + (h2 * scale), math.rad(currentrot * 90), scale, scale, w2,h2, kx, ky)
							end
						end
					end
				else
					EdTweaks.Shadowing = false
				end
			elseif EdTweaks.drawMode == 'fill' then
				if EdTweaks.Shadowing then
					local fillTile = cells[y][x] -- for reference
					local fills = {[y]={[x]=true}}
					api.GetFills(x,y, fillTile, fills)
					for nlx = 1, width do
						for nly = 1, height do
							if fills[nly] and fills[nly][nlx] then
								love.graphics.draw(theTile, ((nlx)*zoom)-offx + (w2 * scale), ((nly)*zoom)-offy + (h2 * scale), math.rad(currentrot * 90), scale, scale, w2,h2, kx, ky)
							end
						end
					end
				end
			else
				love.graphics.draw(theTile, ((x)*zoom)-offx + (w2 * scale), ((y)*zoom)-offy + (h2 * scale), math.rad(currentrot * 90), scale, scale, w2,h2, kx, ky)
			end
			love.graphics.setColor(r,g,b,a)
		else
			EdTweaks.Shadowing = false
		end
	end)
end
