

KReleaseOperation:Bind("All", function(key)
	-- nothin here folks
end)
