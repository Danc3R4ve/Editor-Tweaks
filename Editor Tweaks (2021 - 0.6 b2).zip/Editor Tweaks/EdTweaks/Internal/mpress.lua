

MPressOperation:Bind("Hitbox::DefaultVariables", function(x,y,b, istouch, presses)
	if not inmenu then
		placecells = true
	else
		typing = false
	end
end)

function BindNomenuHitbox(l, _x,_x2,_y,_y2, Fn, adjustRatio)
	MPressOperation:BindOrOverride("Hitbox::"..l, function(x,y,b, istouch, presses)
		--if inmenu then return end
		x = x/winxm
		y = y/winym
		if x>=_x and x<=_x2 and y>=_y and y<=(_y2 * (adjustRatio and (winxm/winym) or 1)) then
			Fn(x,y,b, istouch, presses)
		end
	end)
end
function BindInmenuHitbox(l, _x,_x2,_y,_y2, Fn, adjustRatio)
	MPressOperation:BindOrOverride("Hitbox::"..l, function(x,y,b, istouch, presses)
		if not inmenu then return end
		x = x/winxm
		y = y/winym
		if x>=_x and x<=_x2 and y>=_y and y<=(_y2 * (adjustRatio and (winxm/winym) or 1)) then
			Fn(x,y,b, istouch, presses)
		end
	end)
end

BindInmenuHitbox("CloseMenu", 170,230, 420,480, function()
	inmenu = false
	placecells = false
end)
BindInmenuHitbox("Reset", 270,330, 420,480, function()
	if newheight ~= height-2 or newwidth ~= width-2 then
		undocells = nil
	end
	for y=0,height-1 do
		for x=0,width-1 do
			cells[y][x].ctype = initial[y][x].ctype
			cells[y][x].rot = initial[y][x].rot
		end
	end
	for y=0,newheight+1 do
		initial[y] = initial[y] or {}
		cells[y] = {}
		placeables[y] = placeables[y] or {}
		if y%25 == 0 then chunks[math.floor(y/25)] = {} end
		for x=0,newwidth+1 do
			if x == 0 or x == newwidth+1 or y == 0 or y == newheight+1 then
				initial[y][x] = {
					ctype = walls[border],
					rot = 0
				}
			elseif x >= width-1 or y >= height-1 then
				initial[y][x] = {ctype = 0, rot = 0}
			end
			cells[y][x] = {}
			placeables[y][x] = placeables[y][x] or false
			chunks[math.floor(y/25)][math.floor(x/25)] = {}
		end
	end
	height = newheight+2
	width = newwidth+2
	bgsprites = love.graphics.newSpriteBatch(tex[0])
	for y=0,height-1 do
		for x=0,width-1 do
			cells[y][x].ctype = initial[y][x].ctype
			cells[y][x].rot = initial[y][x].rot
			cells[y][x].lastvars = {x,y,cells[y][x].rot}
			cells[y][x].testvar = ""
			bgsprites:add((x-1)*20,(y-1)*20)
		end
	end
	inmenu = false
	placecells = false
	paused = true
	isinitial = true
	subtick = subtick and 0
	love.audio.play(beep)
	RefreshChunks()
	modsOnReset()
end)
BindInmenuHitbox("Clear", 370,430, 420,480, function()
	undocells = nil
	width = newwidth+2
	height = newheight+2
	love.load()
	inmenu = false
	placecells = false
	paused = true
	isinitial = true
	subtick = subtick and 0
	love.audio.play(beep)
	RefreshChunks()
	modsOnClear()
end)
BindInmenuHitbox("Save", 470,530, 420,480, function()
	if config['use_k2'] == 'true' then
		EncodeK2()
	else
		encodeAP1()
	end
	love.audio.play(beep)
end)
BindInmenuHitbox("Load", 570,630, 420,480, function()
	if string.sub(love.system.getClipboardText(),1,3) == "V3;" then
		DecodeV3(love.system.getClipboardText())
		inmenu = false
		placecells = false
		newwidth = width-2
		newheight = height-2
		love.audio.play(beep)
		undocells = nil
	elseif string.sub(love.system.getClipboardText(),1,3) == "K1;" then
		DecodeK1(love.system.getClipboardText())
		inmenu = false
		placecells = false
		newwidth = width-2
		newheight = height-2
		love.audio.play(beep)
		undocells = nil
	elseif string.sub(love.system.getClipboardText(),1,3) == "K2;" then
		DecodeK2(love.system.getClipboardText())
		inmenu = false
		placecells = false
		newwidth = width-2
		newheight = height-2
		love.audio.play(beep)
		undocells = nil
	elseif string.sub(love.system.getClipboardText(),1,4) == "AP1;" then
		DecodeAP1(love.system.getClipboardText())
		inmenu = false
		placecells = false
		newwidth = width-2
		newheight = height-2
		love.audio.play(beep)
		undocells = nil
	else
		love.audio.play(destroysound)
	end
end)

MPressOperation:Bind("Hitbox::TilePicker", function(x,y,b, istouch, presses)
	if y > 575-20*(winxm/winym) and y < 575+20*(winxm/winym) then
		-- picking a tile in or out of the menu
		for i=0,15 do
			if x > 5+(775-25)*i/15 and x < 45+(775-25)*i/15 and listorder[i+16*(page-1)+1] then
				currentstate = listorder[i+16*(page-1)+1]
				placecells = false
			end
		end
	end
end)

BindInmenuHitbox("DebugCheckbox", 175,195, 375,395, function()
	dodebug = not dodebug
	love.audio.play(beep)
end)
BindInmenuHitbox("InterpolateCheckbox", 375,395, 375,395, function()
	interpolate = not interpolate
	love.audio.play(beep)
end)
BindInmenuHitbox("SubtickingCheckbox", 525,545, 375,395, function()
	if subtick == false then
		subtick = 0
	else
		while subtick > 0 do
			DoTick()
		end
		subtick = false
	end
	love.audio.play(beep)
end)

BindInmenuHitbox("Textbox1", 250,350, 325,350, function()
	typing = 1
end)
BindInmenuHitbox("Textbox2", 450,550, 325,350, function()
	typing = 2
end)

--/ Nomenu
BindNomenuHitbox("OpenMenu", 25,85, 25,85, function()
	inmenu = true
	placecells = false
end, true)
BindNomenuHitbox("ZoomIn", 100,160, 25,85, function()
	if zoom < 160 then
		zoom = zoom*2
		offx = offx*2 + 400*winxm
		offy = offy*2 + 300*winym
	end
	placecells = false
end, true)
BindNomenuHitbox("ZoomOut", 175,235, 25,85, function()
	if zoom > 2 then
		offx = (offx-400*winxm)*0.5
		offy = (offy-300*winym)*0.5
		zoom = zoom*0.5
	end
	placecells = false
end, true)
BindNomenuHitbox("Select", 25,85, 100,160, function()
	selecting = not selecting
	pasting = false
	selw = 0
	selh = 0
	placecells = false
end, true)

MPressOperation:Bind("Hitbox::Copy", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if selecting and x >= 100 and x <= 160 and y >= 25+75*(winxm/winym) and y <= 25+75*(winxm/winym)+60*(winxm/winym) then
		if selw > 0 then
			copied = {}
			for y=0,selh-1 do
				copied[y] = {}
				for x=0,selw-1 do
					copied[y][x] = {}
					copied[y][x].ctype = cells[y+sely][x+selx].ctype
					copied[y][x].rot = cells[y+sely][x+selx].rot
					copied[y][x].place = placeables[y+sely][x+selx]
				end
			end
			selecting = false
		end
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::Cut", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if selecting and x >= 175 and x <= 175+60 and y >= 25+75*(winxm/winym) and y <= 25+75*(winxm/winym)+60*(winxm/winym) then
		if selw > 0 then
			copied = {}
			for y=0,selh-1 do
				copied[y] = {}
				for x=0,selw-1 do
					copied[y][x] = {}
					copied[y][x].ctype = cells[y+sely][x+selx].ctype
					copied[y][x].rot = cells[y+sely][x+selx].rot
					copied[y][x].place = placeables[y+sely][x+selx]
					cells[y+sely][x+selx].ctype = 0
					cells[y+sely][x+selx].rot = 0
					if isinitial then
						initial[y+sely][x+selx].ctype = 0
						placeables[y+sely][x+selx] = false
					end
				end
			end
			selecting = false
		end
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::Cancel-Select", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if x >= 25 and x <= 85 and y >= 25+150*(winxm/winym) and y <= 25+150*(winxm/winym)+60*(winxm/winym) and copied then
		selecting = false
		pasting = true
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::Rotate-Paste", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if x >= 100 and x <= 160 and y >= 25+150*(winxm/winym) and y <= 25+150*(winxm/winym)+60*(winxm/winym) and copied then
		local lastcop = {}
		local selh = #copied
		local selw = #copied[0]
		for y=0,selh do
			lastcop[y] = {}
			for x=0,selw do
				lastcop[y][x] = {}
				lastcop[y][x].ctype = copied[y][x].ctype
				lastcop[y][x].rot = copied[y][x].rot
				lastcop[y][x].place = copied[y][x].place
			end
		end
		for y=0,selh do
			for x=0,selw do
				copied[y][x].ctype = lastcop[y][selw-x].ctype
				if lastcop[y][selw-x].ctype == 8 then copied[y][x].ctype = 9 copied[y][x].rot = lastcop[y][selw-x].rot
				elseif lastcop[y][selw-x].ctype == 9 then copied[y][x].ctype = 8 copied[y][x].rot = lastcop[y][selw-x].rot
				elseif lastcop[y][selw-x].ctype == 17 then copied[y][x].ctype = 18 copied[y][x].rot = lastcop[y][selw-x].rot
				elseif lastcop[y][selw-x].ctype == 18 then copied[y][x].ctype = 17 copied[y][x].rot = lastcop[y][selw-x].rot
				elseif lastcop[y][selw-x].ctype == 25 then copied[y][x].ctype = 26 copied[y][x].rot = (-lastcop[y][selw-x].rot + 2)%4
				elseif lastcop[y][selw-x].ctype == 26 then copied[y][x].ctype = 25 copied[y][x].rot = (-lastcop[y][selw-x].rot + 2)%4
				elseif (lastcop[y][selw-x].ctype == 6 or lastcop[y][selw-x].ctype == 22 or lastcop[y][selw-x].ctype == 30 or lastcop[y][selw-x].ctype == 45 or lastcop[y][selw-x].ctype == 52) and lastcop[y][selw-x].rot%2 == 0 then copied[y][x].rot = (lastcop[y][selw-x].rot - 1)%4
				elseif (lastcop[y][selw-x].ctype == 6 or lastcop[y][selw-x].ctype == 22 or lastcop[y][selw-x].ctype == 30 or lastcop[y][selw-x].ctype == 45 or lastcop[y][selw-x].ctype == 52) then copied[y][x].rot = (lastcop[y][selw-x].rot + 1)%4
				elseif (lastcop[y][selw-x].ctype == 15 or lastcop[y][selw-x].ctype == 56) and lastcop[y][selw-x].rot%2 == 0 then copied[y][x].rot = (lastcop[y][selw-x].rot + 1)%4
				elseif (lastcop[y][selw-x].ctype == 15 or lastcop[y][selw-x].ctype == 56) then copied[y][x].rot = (lastcop[y][selw-x].rot - 1)%4
				else copied[y][x].rot = (-lastcop[y][selw-x].rot + 2)%4 end
				copied[y][x].place = lastcop[y][selw-x].place
			end
		end
		placecells = false
	elseif x >= 175 and x <= 235 and y >= 25+150*(winxm/winym) and y <= 25+150*(winxm/winym)+60*(winxm/winym) and copied then
		local lastcop = {}
		local selh = #copied
		local selw = #copied[0]
		for y=0,selh do
			lastcop[y] = {}
			for x=0,selw do
				lastcop[y][x] = {}
				lastcop[y][x].ctype = copied[y][x].ctype
				lastcop[y][x].rot = copied[y][x].rot
				lastcop[y][x].place = copied[y][x].place
			end
		end
		for y=0,selh do
			for x=0,selw do
				copied[y][x].ctype = lastcop[selh-y][x].ctype
				if lastcop[selh-y][x].ctype == 8 then copied[y][x].ctype = 9 copied[y][x].rot = lastcop[selh-y][x].rot
				elseif lastcop[selh-y][x].ctype == 9 then copied[y][x].ctype = 8 copied[y][x].rot = lastcop[selh-y][x].rot
				elseif lastcop[selh-y][x].ctype == 17 then copied[y][x].ctype = 18 copied[y][x].rot = lastcop[selh-y][x].rot
				elseif lastcop[selh-y][x].ctype == 18 then copied[y][x].ctype = 17 copied[y][x].rot = lastcop[selh-y][x].rot
				elseif lastcop[selh-y][x].ctype == 25 then copied[y][x].ctype = 26 copied[y][x].rot = (-lastcop[selh-y][x].rot)%4
				elseif lastcop[selh-y][x].ctype == 26 then copied[y][x].ctype = 25 copied[y][x].rot = (-lastcop[selh-y][x].rot)%4
				elseif (lastcop[selh-y][x].ctype == 6 or lastcop[selh-y][x].ctype == 22 or lastcop[selh-y][x].ctype == 30 or lastcop[selh-y][x].ctype == 45 or lastcop[selh-y][x].ctype == 52) and lastcop[selh-y][x].rot%2 == 0 then copied[y][x].rot = (lastcop[selh-y][x].rot + 1)%4
				elseif (lastcop[selh-y][x].ctype == 6 or lastcop[selh-y][x].ctype == 22 or lastcop[selh-y][x].ctype == 30 or lastcop[selh-y][x].ctype == 45 or lastcop[selh-y][x].ctype == 52) then copied[y][x].rot = (lastcop[selh-y][x].rot - 1)%4
				elseif (lastcop[selh-y][x].ctype == 15 or lastcop[selh-y][x].ctype == 56) and lastcop[selh-y][x].rot%2 == 0 then copied[y][x].rot = (lastcop[selh-y][x].rot - 1)%4
				elseif (lastcop[selh-y][x].ctype == 15 or lastcop[selh-y][x].ctype == 56) then copied[y][x].rot = (lastcop[selh-y][x].rot + 1)%4
				else copied[y][x].rot = (-lastcop[selh-y][x].rot)%4 end
				copied[y][x].place = lastcop[selh-y][x].place
			end
		end
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::Undo", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if x >= 725-150 and x <= 725-150+60 and y >= 25 and y <= 25+60*(winxm/winym) then
		-- undo cells button
		if undocells then
			for y=0,height-1 do
				for x=0,width-1 do
					cells[y][x].ctype = undocells[y][x].ctype
					cells[y][x].rot = undocells[y][x].rot
					cells[y][x].lastvars = {x,y,undocells[y][x].rot}
					placeables[y][x] = undocells[y][x].place
					if wasinitial then
						initial[y][x].ctype = undocells[y][x].ctype
						initial[y][x].rot = undocells[y][x].rot
					end
				end
			end
			undocells = nil
			placecells = false
		end
		RefreshChunks()
	end
end)
MPressOperation:Bind("Hitbox::Advance-Tick", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if x >= 725-75 and x <= 725-75+60 and y >= 25 and y <= 25+60*(winxm/winym) then
		-- advance one tick
		for y=0,height-1 do
			for x=0,width-1 do
				cells[y][x].lastvars = {x,y,cells[y][x].rot}
			end
		end
		DoTick()
		dtime = 0
		itime = 0
		isinitial = false
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::Pause", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if x >= 725 and x <= 725+60 and y >= 25 and y <= 25+60*(winxm/winym) then
		paused = not paused
		modsOnUnpause()
		isinitial = false
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::Set-Initial", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if x >= 725 and x <= 725+60 and y >= 25+75*(winxm/winym) and y <= 25+75*(winxm/winym)+60*(winxm/winym) and not isinitial then
		if newheight ~= height-2 or newwidth ~= width-2 then
			undocells = nil
		end
		for y=0,newheight+1 do
			initial[y] = initial[y] or {}
			cells[y] = {}
			placeables[y] = placeables[y] or {}
			if y%25 == 0 then chunks[math.floor(y/25)] = {} end
			for x=0,newwidth+1 do
				if x == 0 or x == newwidth+1 or y == 0 or y == newheight+1 then
					initial[y][x] = {
						ctype = walls[border],
						rot = 0,
						lastvars = {x, y, 0}
					}
				elseif x >= width-1 or y >= height-1 then
					initial[y][x] = {ctype = 0, rot = 0}
				end
				cells[y][x] = {}
				placeables[y][x] = placeables[y][x] or false
				chunks[math.floor(y/25)][math.floor(x/25)] = {}
			end
		end
		height = newheight+2
		width = newwidth+2
		bgsprites = love.graphics.newSpriteBatch(tex[0])
		for y=0,height-1 do
			for x=0,width-1 do
				cells[y][x].ctype = initial[y][x].ctype
				cells[y][x].rot = initial[y][x].rot
				cells[y][x].lastvars = {x,y,cells[y][x].rot}
				cells[y][x].testvar = ""
				bgsprites:add((x-1)*20,(y-1)*20)
			end
		end
		placecells = false
		paused = true
		isinitial = true
		subtick = subtick and 0
		RefreshChunks()
		modsOnReset()
	elseif x >= 725-150 and x <= 725-15 and y >= 25+75*(winxm/winym) and y <= 25+75*(winxm/winym)+60*(winxm/winym) and not isinitial then
		for y=0,height-1 do
			for x=0,width-1 do
				initial[y][x].ctype = cells[y][x].ctype
				initial[y][x].rot = cells[y][x].rot
			end
		end
		placecells = false
		paused = true
		isinitial = true
		subtick = subtick and 0
		RefreshChunks()
		modsOnSetInitial()
	end
end)
MPressOperation:Bind("Hitbox::Rotate-Controls", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if x >= 755 and y >= 475-80*(winxm/winym) and x <= 795 and y <= 475-40*(winxm/winym) then
		-- counter-clockwise rotation button
		if pasting then
			local lastcop = {}
			local selh = #copied
			local selw = #copied[0]
			for y=0,selh do
				lastcop[y] = {}
				for x=0,selw do
					lastcop[y][x] = {}
					lastcop[y][x].ctype = copied[y][x].ctype
					lastcop[y][x].rot = copied[y][x].rot
					lastcop[y][x].place = copied[y][x].place
				end
			end
			copied = {}
			for y=0,selw do
				copied[y] = {}
				for x=0,selh do
					copied[y][x] = {}
					copied[y][x].ctype = lastcop[x][selw-y].ctype
					copied[y][x].rot = (lastcop[x][selw-y].rot-1)%4
					copied[y][x].place = lastcop[x][selw-y].place
				end
			end
		else
			currentrot = (currentrot - 1)%4
		end
		placecells = false
	elseif x >= 675 and y >= 475-80*(winxm/winym) and x <= 715 and y <= 475-40*(winxm/winym) then
		-- rotate button
		if pasting then
			local lastcop = {}
			local selh = #copied
			local selw = #copied[0]
			for y=0,selh do
				lastcop[y] = {}
				for x=0,selw do
					lastcop[y][x] = {}
					lastcop[y][x].ctype = copied[y][x].ctype
					lastcop[y][x].rot = copied[y][x].rot
					lastcop[y][x].place = copied[y][x].place
				end
			end
			copied = {}
			for y=0,selw do
				copied[y] = {}
				for x=0,selh do
					copied[y][x] = {}
					copied[y][x].ctype = lastcop[selh-x][y].ctype
					copied[y][x].rot = (lastcop[selh-x][y].rot+1)%4
					copied[y][x].place = lastcop[selh-x][y].place
				end
			end
		else
			currentrot = (currentrot + 1)%4
		end
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::Page-Controls", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if x >= 675 and y >= 475 and x <= 715 and y <= 475+40*(winxm/winym) then
		-- page left button
		page = math.max(page-1,1)
		placecells = false
	elseif x >= 755 and y >= 475 and x <= 795 and y <= 475+40*(winxm/winym) then
		-- page right button
		page = math.min(page+1,math.ceil(#listorder/16))
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::Selection-Adjustment", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if selecting and placecells then
		-- selection box adjustment code
		selx = math.max(math.min(math.floor((love.mouse.getX()+offx)/zoom),width-2),1)
		sely = math.max(math.min(math.floor((love.mouse.getY()+offy)/zoom),height-2),1)
	end
end)
MPressOperation:Bind("Hitbox::Paste-Control", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if pasting and b == 1 then
		-- pasting tiles, paste as many as possible
		pasting = false
		if math.floor((love.mouse.getX()+offx)/zoom) > 0 and math.floor((love.mouse.getX()+offx)/zoom) < width-#copied[0]-1 and math.floor((love.mouse.getY()+offy)/zoom) > 0 and math.floor((love.mouse.getY()+offy)/zoom) < height-#copied-1 then
			undocells = {}
			for y=0,height-1 do
				undocells[y] = {}
				for x=0,width-1 do
					undocells[y][x] = {}
					undocells[y][x].ctype = cells[y][x].ctype
					undocells[y][x].rot = cells[y][x].rot
					undocells[y][x].place = placeables[y][x]
					undocells[y][x].lastvars = {x,y,cells[y][x].rot}
					wasinitial = isinitial
				end
			end
			for y=0,#copied do
				for x=0,#copied[0] do
					cells[y+math.floor((love.mouse.getY()+offy)/zoom)][x+math.floor((love.mouse.getX()+offx)/zoom)].ctype = copied[y][x].ctype
					cells[y+math.floor((love.mouse.getY()+offy)/zoom)][x+math.floor((love.mouse.getX()+offx)/zoom)].rot = copied[y][x].rot
					cells[y+math.floor((love.mouse.getY()+offy)/zoom)][x+math.floor((love.mouse.getX()+offx)/zoom)].lastvars = {x+math.floor((love.mouse.getX()+offx)/zoom),y+math.floor((love.mouse.getY()+offy)/zoom),copied[y][x].rot}
					if isinitial then
						initial[y+math.floor((love.mouse.getY()+offy)/zoom)][x+math.floor((love.mouse.getX()+offx)/zoom)].ctype = copied[y][x].ctype
						initial[y+math.floor((love.mouse.getY()+offy)/zoom)][x+math.floor((love.mouse.getX()+offx)/zoom)].rot = copied[y][x].rot
						placeables[y+math.floor((love.mouse.getY()+offy)/zoom)][x+math.floor((love.mouse.getX()+offx)/zoom)] = copied[y][x].place
					end
				end
			end
			RefreshChunks()
		end
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::PasteClear-Control", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if pasting and b == 2 then
		-- paste, clear paste
		pasting = false
		placecells = false
	end
end)
MPressOperation:Bind("Hitbox::UndoClear-Control", function(x,y,b, istouch, presses)
	x,y = x/winxm,y/winym
	if inmenu then return end
	if placecells and (b == 1 or b == 2) and math.floor((love.mouse.getY()+offy)/zoom) > 0 and math.floor((love.mouse.getX()+offx)/zoom) > 0 and math.floor((love.mouse.getY()+offy)/zoom) < height-1 and math.floor((love.mouse.getX()+offx)/zoom) < width-1 then
		-- if you click anywhere, clear the undo cells, for when you make new ones
		undocells = nil
	end
end)
MPressOperation:Bind("Hitbox::CelLuAPI-Support", function(x,y,b, istouch, presses)
	x = x/winxm
	y = y/winym
	modsOnMousePressed(x, y, b, istouch, presses)
end)

return {}
