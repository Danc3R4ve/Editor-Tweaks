

UpdateOperation:Bind("Variable", function(dt)
	delta = dt
	winxm = (love.graphics.getWidth()/800)
	winym = (love.graphics.getHeight()/600)
end)
UpdateOperation:Bind("Menu::Sliders", function(dt)
	if inmenu then
		if love.mouse.isDown(1) then
			local x,y = love.mouse.getX()/winxm,love.mouse.getY()/winym
			if x >= 145 and x <= 655 then	--give some extra area on the left and right so you can set it to the highest and lowest value more easily
				x = math.min(math.max(x,150),650)	--then cap it so nothing breaks
				if y >= 160 and y <= 170 then
					delay = (x-150)/500
				elseif y >= 195 and y <= 205 then
					tpu = round((x-150)/(500/9))+1
				elseif y >= 230 and y <= 240 then
					volume = round((x-150)/5)/100
					love.audio.setVolume(volume)
				elseif y >= 265 and y <= 275 then
					border = round((x-150)/(500/(#walls-1)))+1
				end
			end
		end
	end
end)
UpdateOperation:Bind("Clock", function(dt)
	if not inmenu then
		if not paused then
			dtime = dtime + dt
			if updatekey > 10000000000 then updatekey = 0 end --juuuust in case
			if supdatekey > 10000000000 then supdatekey = 0 end
			if dtime > delay then
				for y=0,height-1 do
					for x=0,width-1 do
						cells[y][x].lastvars = {x,y,cells[y][x].rot}
					end
				end
				for i=1,tpu do
					DoTick()
				end
				dtime = 0
				itime = 0
			end
		end
	end
end)
UpdateOperation:Bind("Controls::Panning", function(dt)
	local PanSpeed = 10 * 60
	local FastPanSpeed = 25 * 60

	if not inmenu then
		if love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui") then
			if love.keyboard.isDown("w") then offy = offy - FastPanSpeed*dt end
			if love.keyboard.isDown("s") then offy = offy + FastPanSpeed*dt end
			if love.keyboard.isDown("a") then offx = offx - FastPanSpeed*dt end
			if love.keyboard.isDown("d") then offx = offx + FastPanSpeed*dt end
		else
			if love.keyboard.isDown("w") then offy = offy - PanSpeed*dt end
			if love.keyboard.isDown("s") then offy = offy + PanSpeed*dt end
			if love.keyboard.isDown("a") then offx = offx - PanSpeed*dt end
			if love.keyboard.isDown("d") then offx = offx + PanSpeed*dt end
		end
	end
end)
UpdateOperation:Bind("Controls::Placement", function(dt)
	if not inmenu then
		if love.mouse.isDown(1) and placecells then
			local x = love.mouse.getX()/winxm
			local y = love.mouse.getY()/winym
			-- looks like controls
			if x >= 755 and y >= 475-40*(winxm/winym) and x <= 795 and y <= 475 then
				offx = offx + 10*60*dt
			elseif x >= 715 and y >= 475-80*(winxm/winym) and x <= 755 and y <= 475-40*(winxm/winym) then
				offy = offy - 10*60*dt
			elseif x >= 715 and y >= 475 and x <= 755 and y <= 475+40*(winxm/winym) then
				offy = offy + 10*60*dt
			elseif x >= 675 and y >= 475-40*(winxm/winym) and x <= 715 and y <= 475 then
				offx = offx - 10*60*dt
			elseif selecting then
				selw = math.max(math.min(math.floor((love.mouse.getX()+offx)/zoom),width-2),selx) - selx + 1
				selh = math.max(math.min(math.floor((love.mouse.getY()+offy)/zoom),height-2),sely) - sely + 1
			else
				local x = math.floor((love.mouse.getX()+offx)/zoom)
				local y = math.floor((love.mouse.getY()+offy)/zoom)
				if x > 0 and y > 0 and x < width-1 and y < height-1 then
					if not undocells then
						undocells = {}
						for y=0,height-1 do
							undocells[y] = {}
							for x=0,width-1 do
								undocells[y][x] = {}
								undocells[y][x].ctype = cells[y][x].ctype
								undocells[y][x].rot = cells[y][x].rot
								undocells[y][x].place = placeables[y][x]
								wasinitial = isinitial
							end
						end
					end
					if currentstate == -2 then
						if isinitial then
							placeables[y][x] = true
						end
					else
						local original = CopyCell(x, y)
						cells[y][x].ctype = currentstate
						cells[y][x].rot = currentrot
						cells[y][x].lastvars = {x,y,currentrot}
						local originalInitial = CopyTable(initial[y][x])
						if isinitial then
							initial[y][x].ctype = currentstate
							initial[y][x].rot = currentrot
							initial[y][x].lastvars = {x,y,currentrot}
						end
						SetChunk(x,y,currentstate)
						modsOnPlace(currentstate, x, y, currentrot, original, originalInitial)
					end
				end
			end
		end
	end
end)
UpdateOperation:Bind("Controls::Deleting", function(dt)
	if not inmenu then
		if love.mouse.isDown(2) and placecells then
			selw = 0
			selh = 0
			local x = math.floor((love.mouse.getX()+offx)/zoom)
			local y = math.floor((love.mouse.getY()+offy)/zoom)
			if x > 0 and y > 0 and x < width-1 and y < height-1 then
				if not undocells then
					undocells = {}
					for y=0,height-1 do
						undocells[y] = {}
						for x=0,width-1 do
							undocells[y][x] = {}
							undocells[y][x].ctype = cells[y][x].ctype
							undocells[y][x].rot = cells[y][x].rot
							undocells[y][x].place = placeables[y][x]
							wasinitial = isinitial
						end
					end
				end
				if currentstate == -2 then
					if isinitial then
						placeables[y][x] = false
					end
				else
					local original = CopyCell(x, y)
					cells[y][x].ctype = 0
					cells[y][x].rot = 0
					local originalInitial = CopyTable(cells[y][x])
					if isinitial then
						initial[y][x].ctype = 0
						initial[y][x].rot = 0
					end
					SetChunk(x,y,currentstate)
					modsOnPlace(0, x, y, 0, original, originalInitial)
				end
			end
		end
	end
end)
UpdateOperation:Bind("VKeyboard", function(dt)
	if not typing then
		newwidth = math.max(newwidth,1)
		newheight = math.max(newheight,1)
	end
end)
UpdateOperation:Bind("PostClock", function(dt)
	itime = math.min(itime + dt,delay)
end)
UpdateOperation:Bind("EnemyParticles", function(dt)
	enemyparticles:update(dt)
end)

return {}
