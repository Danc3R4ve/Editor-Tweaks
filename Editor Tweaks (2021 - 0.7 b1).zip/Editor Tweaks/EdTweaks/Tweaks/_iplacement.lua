return function(api)
	local lmx,lmy
	function api.Place(x,y)
		local placing = currentstate
		local rotation = currentrot

		if api.orientationMode == 'Random' then
			rotation = math.random(0,3)
		end
		if api.orientationMode == 'RoundRobin' then
			rotation = ((x+y)%4)
		end

		-- Check CanPlace conditionals to see if a mod is blocking this tile's placement
		if EdTweaks.Conditionals and EdTweaks.Modded.CanPlace then
			for Label, Data in pairs(EdTweaks.Modded.CanPlace) do
				if (Data.Block == placing) and (not Data.Function(placing, rotation, x,y)) then
					return false
				end
			end
		end

		if x > 0 and y > 0 and x < width-1 and y < height-1 then
			if not undocells then
				undocells = {}
				for y=0,height-1 do
					undocells[y] = {}
					for x=0,width-1 do
						undocells[y][x] = {}
						undocells[y][x].ctype = cells[y][x].ctype
						undocells[y][x].rot = cells[y][x].rot
						undocells[y][x].place = placeables[y][x]
						wasinitial = isinitial
					end
				end
			end
			if placing == -2 then
				if isinitial then
					placeables[y][x] = true
				end
			else
				local original = CopyCell(x, y)
				cells[y][x].ctype = placing
				cells[y][x].rot = rotation
				cells[y][x].lastvars = {x,y,rotation}
				local originalInitial = CopyTable(initial[y][x])
				if isinitial then
					initial[y][x].ctype = placing
					initial[y][x].rot = rotation
					initial[y][x].lastvars = {x,y,rotation}
				end
				SetChunk(x,y,placing)
				modsOnPlace(placing, x, y, rotation, original, originalInitial)
			end
		end
		return true, placing, rotation
	end
	MReleaseOperation:Bind("Controls::Placement-End", function(x,y,b, istouch)
		if not placecells then return end
		if not inmenu then
			local x = math.floor((x+offx)/zoom)
			local y = math.floor((y+offy)/zoom)
			if EdTweaks.drawMode == 'line' then
				if EdTweaks.Anchor and EdTweaks.Shadowing then
					local ax,ay = EdTweaks.Anchor.x, EdTweaks.Anchor.y
					api.line( ax,ay, x,y, function(nlx,nly, draw_count)
						api.Place(nlx,nly)
						return true
					end)
					EdTweaks.Anchor = nil
				end
			elseif EdTweaks.drawMode == 'square' then
				if EdTweaks.Anchor and EdTweaks.Shadowing then
					local ax,ay = EdTweaks.Anchor.x, EdTweaks.Anchor.y
					local x1,y1,x2,y2 = math.min(ax,x),math.min(ay,y),math.max(ax,x),math.max(ay,y)
					if api.drawConfig.isFilled then
						for nlx = x1, x2 do
							for nly = y1, y2 do
								api.Place(nlx,nly)
							end
						end
					else
						for nlx = x1, x2 do
							for nly = y1, y2 do
								if nlx == x1 or nlx == x2 or nly == y1 or nly == y2 then
									api.Place(nlx,nly)
								end
							end
						end
					end
					EdTweaks.Anchor = nil
				end
			elseif EdTweaks.drawMode == 'circle' then
				if EdTweaks.Anchor and EdTweaks.Shadowing then
					local ax,ay = EdTweaks.Anchor.x, EdTweaks.Anchor.y
					local x1,y1,x2,y2 = math.min(ax,x),math.min(ay,y),math.max(ax,x),math.max(ay,y) -- get min / max coords for absolute rendering
					for nlx = x1, x2 do
						local xs = (nlx - x1) / math.max(1, x2 - x1) -- get x ratio (0 - 1) with quick maths
						for nly = y1, y2 do
							local ys = (nly - y1) / math.max(1, y2 - y1) -- same for the y ratio, 0 - 1
							local n = ((xs - 0.5) ^ 2) + ((ys - 0.5) ^ 2)
							if api.drawConfig.isFilled and (n <= 0.51 ^ 2) or -- if is in range
								(x2-x1<1) or (y2-y1<1) then -- or is a straight line
								api.Place(nlx,nly) -- then place at the tile
							elseif (not api.drawConfig.isFilled) and ((n >= 0.4 ^ 2) and (n <= 0.51 ^ 2)) or -- if is in range
								(x2-x1<1) or (y2-y1<1) then -- or is a straight line
								api.Place(nlx,nly) -- then place at the tile
							end
						end
					end
					EdTweaks.Anchor = nil
				end
			end
		end
	end)
	MPressOperation:Bind("Controls::Placement-Start", function(x,y,b, istouch)
		lmx,lmy = nil,nil
		if not placecells then return end
		if not EdTweaks.Shadowing then return end
		if b~=1 then return end
		if not inmenu then
			local x = math.floor((x+offx)/zoom)
			local y = math.floor((y+offy)/zoom)
			if EdTweaks.drawMode == 'fill' then
				local fillTile = cells[y][x] -- for reference
				local fills = {[y]={[x]=true}} -- give us our initial fill
				api.GetFills(x,y, fillTile, fills) -- populate the array with our new tiles
				for nlx = 1, width do
					for nly = 1, height do
						if fills[nly] and fills[nly][nlx] then -- if we can fill this tile
							api.Place(nlx,nly) -- do eet
						end
					end
				end
			end
		end
	end)
	UpdateOperation:Override("Controls::Placement", function(dt)
		if not inmenu then
			if love.mouse.isDown(1) and placecells then
				local x = love.mouse.getX()/winxm
				local y = love.mouse.getY()/winym
				local dist = 40*(winxm/winym)
				-- looks like controls
				if x >= 755 and y >= 525 and x <= 795 and y <= 525+dist then
					-- r
					offx = offx + 10*60*dt
				elseif x >= 715 and y >= 525-dist and x <= 755 and y <= 525 then
					-- u
					offy = offy - 10*60*dt
				elseif x >= 715 and y >= 525 and x <= 755 and y <= 525+dist then
					-- d
					offy = offy + 10*60*dt
				elseif x >= 675 and y >= 525 and x <= 715 and y <= 525+dist then
					-- l
					offx = offx - 10*60*dt
				elseif selecting then
					selw = math.max(math.min(math.floor((love.mouse.getX()+offx)/zoom),width-2),selx) - selx + 1
					selh = math.max(math.min(math.floor((love.mouse.getY()+offy)/zoom),height-2),sely) - sely + 1
				elseif (EdTweaks.drawMode == 'line') or (EdTweaks.drawMode == 'circle') or (EdTweaks.drawMode == 'square') then
					local x = math.floor((love.mouse.getX()+offx)/zoom)
					local y = math.floor((love.mouse.getY()+offy)/zoom)
					if not EdTweaks.Anchor then
						EdTweaks.Anchor = {x=x;y=y;}
					end
				elseif EdTweaks.drawMode == 'free' then
					local x = math.floor((love.mouse.getX()+offx)/zoom)
					local y = math.floor((love.mouse.getY()+offy)/zoom)
					-- updated free placement with line interpolations, so there are no gaps in the drawing (99% of the time)
					if lmx and lmy and api.Shadowing then
						api.line( lmx,lmy, x,y, function(nlx,nly, draw_count)
							api.Place(nlx,nly)
							return true
						end)
					elseif api.Shadowing then
						api.Place(x,y)
					end
					lmx, lmy = x, y
				end
			else
				EdTweaks.Anchor = nil
				lmx, lmy = nil, nil
			end
		else
			EdTweaks.Anchor = nil
			lmx, lmy = nil, nil
		end
	end)
end
