return function(api)
	local ol = false
	--AP1;16;E;m|ETw Cloak|0|15|;v|28|0|12|;m|ETw Cloak|0|2|;v|28|0|1|;v|F|0|1|;v|1|0|D|;v|0|0|1|;v|F|1|1|;v|28|0|1|;m|ETw Cloak|0|2|;v|28|0|1|;v|F|3|1|;v|F|1|1|;v|0|0|C|;v|F|0|1|;v|F|2|1|;v|28|0|1|;m|ETw Cloak|0|2|;v|28|0|2|;v|F|3|1|;v|F|1|1|;v|0|0|A|;v|F|0|1|;v|F|2|1|;v|28|0|2|;m|ETw Cloak|0|3|;v|28|0|2|;v|F|3|1|;v|F|1|1|;v|0|0|8|;v|F|0|1|;v|F|2|1|;v|28|0|2|;m|ETw Cloak|0|5|;v|28|0|2|;v|F|3|1|;v|F|1|1|;v|0|0|6|;v|F|0|1|;v|F|2|1|;v|28|0|2|;m|ETw Cloak|0|7|;v|28|0|2|;v|F|3|1|;v|F|1|1|;v|0|0|4|;v|F|0|1|;v|F|2|1|;v|28|0|2|;m|ETw Cloak|0|9|;v|28|0|2|;v|F|3|1|;v|F|1|1|;v|0|0|2|;v|F|0|1|;v|F|2|1|;v|28|0|2|;m|ETw Cloak|0|B|;v|28|0|2|;v|F|3|1|;v|0|0|2|;v|F|2|1|;v|28|0|2|;m|ETw Cloak|0|D|;v|28|0|6|;m|ETw Cloak|0|1B|;
	api.ZoomToGrid = function()
		local yratio = (love.graphics.getHeight() / height) / 20
		zoom = math.floor(20 * yratio)
		local xratio = (width * 20) * yratio
		offx = -math.floor(0.5 + (love.graphics.getWidth() / 2) - (xratio/2))
		offy = 0
	end
	api.NewGrid = function(gx,gy)
		cells = {}
		gx,gy = gx+2,gy+2
		width, height = gx,gy
		newwidth, newheight = width-2, height-2
		for y = 0, height do
			cells[y] = {}
			for x = 0, width do
				local isborder = (y==0 or y==height or x==0 or x==width) and 47 or 0
				cells[y][x] = {
					ctype = isborder;
					rot = 0;
				}
			end
		end
		api.resetBGSprites()
		api.ZoomToGrid()
	end
	KPressOperation:Bind("Controls::P", function(key,scancode,isrepeat)
		if key == "p" and (love.keyboard.isDown("lctrl") or love.keyboard.isDown("rctrl")) then
			api.ZoomToGrid()
		end
	end)
	api.onload = function()
		if ol then return end
		ol = true
		api.NewGrid(24,24)
	end
end
