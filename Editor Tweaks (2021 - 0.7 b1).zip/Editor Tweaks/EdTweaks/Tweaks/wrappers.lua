return function(api)
	do
		--/ Override addcell to add unsorted content
		local oldaddCell = addCell
		function addCell(label, ...)

			local cellID = oldaddCell(label, ...)
			EdTweaks:RegisterImage(label, cellID, nil, tex[cellID]) --:match"^(.+)%.png$" or texture)
			if api.AllModdedContentCategory() then
				api.AllModdedContentCategory():AddItem(label, "Modded item.")
			end
			return cellID
		end
		local B = MPressOperation:FindBindByLabel"Hitbox::Page-Controls"
		if B then
			MPressOperation:Unbind(B.label)
		end
	end
end
