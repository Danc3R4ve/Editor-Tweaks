return function(api)
	api.timer = 0 -- game's tweak clock
	api.delays = {}
	-- Activates a function after a specified time, relies on the init's clock
	function api.delay(time, fn)
		table.insert(api.delays, {initTimer = api.timer; endtime = time; f=fn})
	end
	-- Ticks up the init's clock
	UpdateOperation:Bind("EditorTweaks::Clock", function(dt)
		api.timer = api.timer + dt
		for i = #api.delays, 1, -1 do
			if api.timer - api.delays[i].endtime >= api.delays[i].initTimer then
				api.delays[i].f()
				table.remove(api.delays, i)
			end
		end
	end)
end
