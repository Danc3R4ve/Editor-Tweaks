return function(self)
	local gt = function(keys, n)
		for index, d in pairs(keys) do
			--error(index.. " " .. tostring(d).. " " .. name.. " " ..n)
			if n==d then
				return index
			end
		end
		return 'nil'
	end
	local aspl = function(str, dlm) -- advanced split, without a required delimiter at the end
		local t,c,i = {},"",0
		while i<#str do
			i=i+1
			if str:sub(i,i+(dlm:len()-1)) == dlm then
				if #c>0 then
					table.insert(t, c)
				end
				i,c=i+(dlm:len()-1),""
			else
				c=c..str:sub(i,i)
			end
		end
		if #c>0 then t[#t+1]=c end
		return t
	end
	function self.Encode(map)
		local a = "ETW; "
		local tags = {}
		for y,c in pairs(map) do
			for x,d in pairs(c) do
				if (d.ctype <= initialCellCount) then
					tags[d.ctype] = true
				elseif not tags[d.ctype] then
					tags[d.ctype] = getCellLabelById(d.ctype)
				end
			end
		end
		local k = {}
		for key,translation in pairs(tags) do
			if type(translation)~="boolean" then
				table.insert(k,translation)
			else
				table.insert(k,key)
			end
		end
		table.sort(k, function(n1,n2) return tostring(n1)<tostring(n2) end)
		local b = table.concat(k, ",").."; "
		local c = ""
		a=a..(width).. "|"..(height).."; "
		for y = 1, height-2 do
			local lst,lsc = nil,0
			for x = 1, width-2 do -- from 0 to width-1
				local cell = map[y][x] -- cell is map[y][x]
				local ct, cta = cell.ctype, tags[cell.ctype] -- celltype, celltype tag shorthand
				local savestr = (""..gt(k,(type(cta) == 'boolean') and ct or cta)..((cell.rot~=0) and ","..cell.rot or ""))
				if lst==savestr then -- same savestr as last one
					lsc = lsc + 1
				elseif (lst == nil) then -- no savestr yet
					lsc, lst = 1, savestr
				else -- savestr changed! it previously existed!
					if lsc>1 then -- if more than one entry
						c = c .. lsc.."x"..lst.. "|" -- note it down as a multiple amount
					else
						c = c .. lst.. "|" -- or just write down a singular entry
					end
					lsc, lst = 1, savestr
				end
			end
			if lsc>0 then
				if lsc>1 then
					c = c .. lsc.."x"..lst.. "|"
				else
					c = c .. lst.. "|"
				end
			end
			c = c:sub(1,-2) .. '>'
		end
		return a..b..(c:sub(1,-2))
	end
	function self.Decode(str)
		local DType, WHDataX, WHDataY, KMap, LData = str:match"^(.+); ?(%d+)|(%d+); ?(.+); ?(.+);?$"
		if DType ~= "ETW" then return end
		local m = {}
		local k = aspl(KMap, ',')
		local lines = aspl(LData, '>')
		width, height = tonumber(WHDataX), tonumber(WHDataY)
		newwidth, newheight = width-2, height-2
		m = {}
		for y = 0, height do
			m[y] = {}
			for x = 0, width do
				m[y][x] = {
					ctype = ((x==0 or x==width-1 or y==0 or y==width-1) and 40) or 0;
					rot = 0;
					lastvars = {x,y,0};
				}
			end
		end
		for y = 1, #lines do
			local line, x, le = aspl(lines[y], '|'), 0, 0
			while le < #line do
				x, le = x + 1, le + 1
				local entry, kentry = line[le], nil
				local amnt, tid, rot, spc = 1, nil, 0, 0
				if entry:match"^(%d+)x(%d+),(%d+)$" then
					-- full complexity
					amnt, tid, rot = entry:match"^(%d+)x(%d+),(%d+)$"
				elseif entry:match"^(%d)xt(%d+),(%d+)$" then
					-- full complexity + modded tag
					amnt, tid, rot = entry:match"^(%d+)xt(%d+),(%d+)$"
				elseif entry:match"^(%d+),(%d+)$" then
					-- single cells with rotation
					tid, rot = entry:match"^(%d+),(%d+)$"
				elseif entry:match"^(%d+)x(%d+)$" then
					-- single cells with quantity
					amnt, tid = entry:match"^(%d+)x(%d+)$"
				elseif entry:match"^(%d+)$" then
					-- single cells with default rotation
					tid = entry:match"^(%d+)$"
				elseif entry:match"^+(%d+)$" then
					-- empty space, compressenated
					spc = tonumber(entry:match"^+(%d+)$") - 1
				else
					error("Unreadable tile: " ..entry)
				end
				amnt, rot = tonumber(amnt) or 1, tonumber(rot) or 0
				if tonumber(tid) then
					local tag = tonumber(tid)
					local _kentry = tonumber(k[tag]) or k[tag]
					if _kentry and (type(_kentry)=='number') then
						kentry = _kentry
					else
						kentry = getCellIDByLabel(_kentry)
						if not kentry then
							error("Missing mod for entry: " ..tostring(_kentry).." (ind " ..tag.. " of table{"..table.concat(k,",").."}). Please install it and try again.")
						end
					end
					for i = 0, amnt-1 do
						if kentry then
							m[y][x].ctype = kentry
							m[y][x].rot = rot
						end
						if i < amnt-1 then x = x + 1 end
					end
				elseif spc > 0 then
					x = x + spc
				end
			end
		end
		EdTweaks.resetBGSprites()
		EdTweaks.ZoomToGrid()
		return m
	end
end
