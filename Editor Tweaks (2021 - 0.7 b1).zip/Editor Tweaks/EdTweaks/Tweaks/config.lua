return function(api)
	local dir = "ModEngine/Mods/Editor Tweaks/EdTweaks/" -- editor tweaks asset folder location
	local internaldir = dir.."Internal/_internals" -- editor tweaks "_internals" lua script location
	api.KeyMap = { -- shortcut controls
		Free = {'n'};
		Line = {'m'};
		Square = {'h'};
		Circle = {'j'};
		Fill = {'y'};

		PageUp = {'pageup'};
		PageDown = {'pagedown'};
		Select = {'return', 'right'};
		Up = {'up'};
		Down = {'down'};
		Fuzzy = {'b'};
		Filled = {'g'};
		Orientation = {'t'};
		KBMode = {'v'};
	}
	api.debugging = false -- show information relevant to etweaks (for debugging)
	api.AllExtraCategoryEnabled = false
	api.drawMode = 'free' -- which mode to start the editor in?
	api.internal = require(internaldir)
	api.Categories = {}
	api.Images = {}
	showinstructions = false -- dont show the instructional text by default
	--/ Ghost Tiles
	local adjacentSearch = {
		function(x,y) return x-1,y-1 end;
		function(x,y) return x,y-1 end;
		function(x,y) return x+1,y-1 end;
		function(x,y) return x-1,y end;
		function(x,y) return x+1,y end;
		function(x,y) return x-1,y+1 end;
		function(x,y) return x,y+1 end;
		function(x,y) return x+1,y+1 end;
	}
end
