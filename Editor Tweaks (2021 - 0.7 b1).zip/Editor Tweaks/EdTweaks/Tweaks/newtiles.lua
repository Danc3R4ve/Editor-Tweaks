return function(api)
	local bgtiles, cloaks, cloakinit, BGr,BGg,BGb = {},{}, false, 1/8,1/8,1/8
	api.TileIDs = {}
	api.Cloaks = cloaks
	local unpushable = function() return false end
	local c = addCell("ETw Cloak", api.dir .. "Images/editor_l_fuzzy.png", {push = unpushable})
	api.TileIDs.Cloak = c
	local function resetBGSprites()
		--bgsprites:release()
		bgsprites = love.graphics.newSpriteBatch(tex[0])
		for y=0,height-1 do
			bgtiles[y] = {}
			for x=0,width-1 do
				local isInvisible = (not (cloaks[y]==nil or cloaks[y][x]~=true))
					or (cells[y] and cells[y][x].ctype == c)
				bgtiles[y][x] = bgsprites:add((x-1)*20,(y-1)*20, 0, isInvisible and 0 or 1, isInvisible and 0 or 1)
			end
		end
	end
	EdTweaks.resetBGSprites = resetBGSprites
	local function AlsoUncloak(v1,v2,_x,_y)
		if v1==v2 then
			if not cloaks[_y] then cloaks[_y]={} end
			cloaks[_y][_x] = nil
			bgsprites:set(bgtiles[_y][_x], (_x-1)*20,(_y-1)*20, 0, 1,1)
		end
	end
	local function AlsoCloak(v1,v2,_x,_y)
		if v1==v2 then
			if not cloaks[_y] then cloaks[_y]={} end
			cloaks[_y][_x] = true
			bgsprites:set(bgtiles[_y][_x], (_x-1)*20,(_y-1)*20, 0, 0,0)
		end
	end
	function EdTweaks.Cloak(x,y)
		if not cloaks[y] then cloaks[y] = {} end
		cloaks[y][x] = true
		bgsprites:set(bgtiles[y][x], (x)*20,(y)*20, 0, 0,0)
		--debug_lastkeypres = x.. ", " ..width
		AlsoCloak(x,1,0,y)
		AlsoCloak(x,width-2,width-1,y)
		AlsoCloak(y,1,x,0)
		AlsoCloak(y,height-2,x,height-1)

		AlsoCloak(x+y,2,x-1,y-1)
		AlsoCloak(x+y,(width-2)+(height-2),(width-1), (height-1))
		if y==1 and x==width-2 then
			AlsoCloak(0,0,x+1,y-1)
		elseif y==height-2 and x==1 then
			AlsoCloak(0,0,x-1,y+1)
		end
	end
	function EdTweaks.Uncloak(x,y, c)
		if not cloaks[y] then cloaks[y] = {} end
		pcall(function()
			cloaks[y][x] = nil
			bgsprites:set(bgtiles[y][x], (x-1)*20,(y-1)*20, 0, 1,1)
			AlsoUncloak(x,1,0,y) -- y, 0
			AlsoUncloak(x,width-2,width-1,y) -- w-1, y
			AlsoUncloak(y,1,x,0) -- x, 0
			AlsoUncloak(y,height-2,x,height-1) -- x, h-1

			AlsoUncloak(x+y,2,x-1,y-1) -- 0, 0
			AlsoUncloak(x+y,(width-2)+(height-2),(width-1), (height-1)) -- w-2, h-2
			if y==1 and x==width-2 then
				AlsoUncloak(0,0,x+1,y-1)
			elseif y==height-2 and x==1 then
				AlsoUncloak(0,0,x-1,y+1)
			end
		end)
	end
	DrawOperation:Override("Tile", function()
		for y=math.max(math.floor(offy/zoom)-1,0),math.min(math.floor((offy+600*winym)/zoom)+1,height-1) do
			for x=math.max(math.floor(offx/zoom)-1,0),math.min(math.floor((offx+800*winxm)/zoom)+1,width-1) do
				assert(cells[y] and cells[y][x], "Incomplete cell table at " ..y..","..x..".")
				if cells[y][x].ctype ~= 0 and (not (cloaks[y] and cloaks[y][x])) then
					love.graphics.draw(
						(tex[cells[y][x].ctype] or tex.nonexistant),
						math.floor(lerp(cells[y][x].lastvars[1],x,itime/delay)*zoom-offx+zoom/2),
						math.floor(lerp(cells[y][x].lastvars[2],y,itime/delay)*zoom-offy+zoom/2),
						lerp(cells[y][x].lastvars[3],cells[y][x].lastvars[3]+((cells[y][x].rot-cells[y][x].lastvars[3]+2)%4-2),itime/delay)*math.pi/2,
						zoom/(texsize[cells[y][x].ctype] or texsize["nonexistant"]).w,
						zoom/(texsize[cells[y][x].ctype] or texsize["nonexistant"]).h,
						(texsize[cells[y][x].ctype] or texsize["nonexistant"]).w2,
						(texsize[cells[y][x].ctype] or texsize["nonexistant"]).h2
					)
				end
				if dodebug then
					love.graphics.print(tostring(cells[y][x].testvar),x*zoom-offx+zoom/2,y*zoom-offy+zoom/2)
				end
				modsOnCellDraw(cells[y][x].ctype, x, y, cells[y][x].rot)
			end
		end
	end)
	MPressOperation:Override("Hitbox::Paste-Control", function(x,y,b, istouch, presses)
		x,y = x/winxm,y/winym
		if inmenu then return end
		if pasting and b == 1 then
			-- pasting tiles, paste as many as possible
			pasting = false
			if math.floor((love.mouse.getX()+offx)/zoom) > 0 and math.floor((love.mouse.getX()+offx)/zoom) < width-#copied[0]-1 and math.floor((love.mouse.getY()+offy)/zoom) > 0 and math.floor((love.mouse.getY()+offy)/zoom) < height-#copied-1 then
				undocells = {}
				for y=0,height-1 do
					undocells[y] = {}
					for x=0,width-1 do
						undocells[y][x] = {}
						undocells[y][x].ctype = cells[y][x].ctype
						undocells[y][x].rot = cells[y][x].rot
						undocells[y][x].place = placeables[y][x]
						undocells[y][x].lastvars = {x,y,cells[y][x].rot}
						wasinitial = isinitial
					end
				end
				for y=0,#copied do
					for x=0,#copied[0] do
						local _x,_y = x,y
						local x,y = x+math.floor((love.mouse.getX()+offx)/zoom), y+math.floor((love.mouse.getY()+offy)/zoom)
						cells[y][x].ctype = copied[_y][_x].ctype
						cells[y][x].rot = copied[_y][_x].rot
						cells[y][x].lastvars = {x,y,copied[_y][_x].rot}
						if cells[y][x].ctype == c then
							EdTweaks.Cloak(x,y)
						else
							EdTweaks.Uncloak(x,y)
						end
						if isinitial then
							initial[y][x].ctype = copied[_y][_x].ctype
							initial[y][x].rot = copied[_y][_x].rot
							placeables[y][x] = copied[_y][_x].place
						end
					end
				end
				RefreshChunks()
				resetBGSprites()
			end
			placecells = false
		end
	end)
	if Cel then
		-- Cel Mod Loader
		Cel.engine:BindCelLuAPIEvent('onPlace', function(id,x,y,rot)
			if id == c then
				if not cloakinit then
					cloakinit = true
					resetBGSprites()
				end
				EdTweaks.Cloak(x,y)
			else
				EdTweaks.Uncloak(x,y)
			end
		end)
		Cel.engine:BindCelLuAPIEvent('onReset', function()
			resetBGSprites()
		end)
		Cel.engine:BindCelLuAPIEvent('onClear', function()
			for _,v in pairs(cloaks) do
				cloaks[_] = nil
			end
			resetBGSprites()
		end)
	else
		-- Some other nooby loader :O requires way more overriden bindings
		EdTweaks.ExternalLoad(resetBGSprites, c)
	end
	resetBGSprites()
	KPressOperation:Override("KeyBind::CTRL+R", function(key, scancode, isrepeat)
		if typing then return end
		if key == 'r' then
			if love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui") then
				if newheight ~= height-2 or newwidth ~= width-2 then
					undocells = nil
				end
				for y=0,newheight+1 do
					initial[y] = initial[y] or {}
					cells[y] = {}
					placeables[y] = placeables[y] or {}
					if y%25 == 0 then chunks[math.floor(y/25)] = {} end
					for x=0,newwidth+1 do
						if x == 0 or x == newwidth+1 or y == 0 or y == newheight+1 then
							if border == 1 then
								initial[y][x] = {ctype = -1, rot = 0}
							elseif border == 2 then
								initial[y][x] = {ctype = 40, rot = 0}
							elseif border == 3 then
								initial[y][x] = {ctype = 11, rot = 0}
							elseif border == 4 then
								initial[y][x] = {ctype = 50, rot = 0}
							end
						elseif x >= width-1 or y >= height-1 then
							initial[y][x] = {ctype = 0, rot = 0}
						end
						cells[y][x] = {}
						placeables[y][x] = placeables[y][x] or false
						chunks[math.floor(y/25)][math.floor(x/25)] = {}
					end
				end
				height = newheight+2
				width = newwidth+2
				for y=0,height-1 do
					for x=0,width-1 do
						cells[y][x].ctype = initial[y][x].ctype
						cells[y][x].rot = initial[y][x].rot
						cells[y][x].lastvars = {x,y,cells[y][x].rot}
						cells[y][x].testvar = ""
					end
				end
				resetBGSprites()
				paused = true
				isinitial = true
				subtick = subtick and 0
				RefreshChunks()
				modsOnReset()
			end
		end
	end)
	BindInmenuHitbox("Reset", 270,330, 420,480, function()
		if newheight ~= height-2 or newwidth ~= width-2 then
			undocells = nil
		end
		for y=0,height-1 do
			for x=0,width-1 do
				cells[y][x].ctype = initial[y][x].ctype
				cells[y][x].rot = initial[y][x].rot
			end
		end
		for y=0,newheight+1 do
			initial[y] = initial[y] or {}
			cells[y] = {}
			placeables[y] = placeables[y] or {}
			if y%25 == 0 then chunks[math.floor(y/25)] = {} end
			for x=0,newwidth+1 do
				if x == 0 or x == newwidth+1 or y == 0 or y == newheight+1 then
					initial[y][x] = {
						ctype = walls[border],
						rot = 0
					}
				elseif x >= width-1 or y >= height-1 then
					initial[y][x] = {ctype = 0, rot = 0}
				end
				cells[y][x] = {}
				placeables[y][x] = placeables[y][x] or false
				chunks[math.floor(y/25)][math.floor(x/25)] = {}
			end
		end
		height = newheight+2
		width = newwidth+2
		for y=0,height-1 do
			for x=0,width-1 do
				cells[y][x].ctype = initial[y][x].ctype
				cells[y][x].rot = initial[y][x].rot
				cells[y][x].lastvars = {x,y,cells[y][x].rot}
				cells[y][x].testvar = ""
			end
		end
		resetBGSprites()
		inmenu = false
		placecells = false
		paused = true
		isinitial = true
		subtick = subtick and 0
		love.audio.play(beep)
		RefreshChunks()
		modsOnReset()
	end)
	function EdTweaks.CheckAllCloaks()
		-- slow algo, but it works nonetheless
		for y = 0, width-1 do
			for x = 0, height-1 do
				EdTweaks.Uncloak(x,y)
			end
		end
		for y = 0, width-1 do
			for x = 0, height-1 do
				if x==0 or x==width-1 or y==0 or y==height-1 then
					if cells[y] and cells[y][x] then
						if cells[y][x].ctype == c then
							EdTweaks.Cloak(x,y)
						elseif EdTweaks.Cloaks[y] and EdTweaks.Cloaks[y][x] then
							EdTweaks.Uncloak(x,y)
						end
					end
				end
			end
		end
		for y = 0, width-1 do
			for x = 0, height-1 do
				if not (x==0 or x==width-1 or y==0 or y==height-1) then
					if cells[y] and cells[y][x] then
						if cells[y][x].ctype == c then
							EdTweaks.Cloak(x,y)
						elseif EdTweaks.Cloaks[y] and EdTweaks.Cloaks[y][x] then
							EdTweaks.Uncloak(x,y)
						end
					end
				end
			end
		end
	end
	local CheckAllCloaks = EdTweaks.CheckAllCloaks
	BindInmenuHitbox("Load", 570,630, 420,480, function()
		if string.sub(love.system.getClipboardText(),1,3) == "V3;" then
			DecodeV3(love.system.getClipboardText())
			inmenu = false
			placecells = false
			newwidth = width-2
			newheight = height-2
			love.audio.play(beep)
			undocells = nil
			resetBGSprites()
			CheckAllCloaks()
		elseif string.sub(love.system.getClipboardText(),1,3) == "K1;" then
			DecodeK1(love.system.getClipboardText())
			inmenu = false
			placecells = false
			newwidth = width-2
			newheight = height-2
			love.audio.play(beep)
			undocells = nil
			resetBGSprites()
			CheckAllCloaks()
		elseif string.sub(love.system.getClipboardText(),1,3) == "K2;" then
			DecodeK2(love.system.getClipboardText())
			inmenu = false
			placecells = false
			newwidth = width-2
			newheight = height-2
			love.audio.play(beep)
			undocells = nil
			resetBGSprites()
			CheckAllCloaks()
		elseif string.sub(love.system.getClipboardText(),1,4) == "AP1;" then
			DecodeAP1(love.system.getClipboardText())
			inmenu = false
			placecells = false
			newwidth = width-2
			newheight = height-2
			love.audio.play(beep)
			undocells = nil
			resetBGSprites()
			CheckAllCloaks()
		elseif string.sub(love.system.getClipboardText(),1,4) == "AP2;" then
			DecodeAP2(love.system.getClipboardText())
			inmenu = false
			placecells = false
			newwidth = width-2
			newheight = height-2
			love.audio.play(beep)
			undocells = nil
			resetBGSprites()
			CheckAllCloaks()
		elseif string.sub(love.system.getClipboardText(),1,4) == "ETW;" then
			cells = EdTweaks.Decode(love.system.getClipboardText())
			inmenu = false
			placecells = false
			newwidth = width-2
			newheight = height-2
			love.audio.play(beep)
			undocells = nil
			resetBGSprites()
			CheckAllCloaks()
		else
			love.audio.stop(destroysound)
			love.audio.play(destroysound)
		end
	end)
	BindInmenuHitbox("Save", 470,530, 420,480, function()
		if love.keyboard.isDown("lshift") or love.keyboard.isDown("rshift") then
			love.system.setClipboardText(EdTweaks.Encode(cells))
			love.audio.stop(beep)
			love.audio.play(beep)
			return
		end
		if config['use_k2'] == 'true' then
			EncodeK2()
		else
			encodeAP1()
		end
		love.audio.play(beep)
	end)
	local function Cut()
		if selecting and selh > 0 then
			copied = {}
			for y=0,selh-1 do
				copied[y] = {}
				for x=0,selw-1 do
					copied[y][x] = {}
					copied[y][x].ctype = cells[y+sely][x+selx].ctype
					copied[y][x].rot = cells[y+sely][x+selx].rot
					copied[y][x].place = placeables[y+sely][x+selx]
					cells[y+sely][x+selx].ctype = 0
					cells[y+sely][x+selx].rot = 0
					if isinitial then
						initial[y+sely][x+selx].ctype = 0
						placeables[y+sely][x+selx] = false
					end
				end
			end
			selecting = false
			CheckAllCloaks()
		end
		placecells = false
	end
	MPressOperation:Override("Hitbox::Cut", function(x,y,b, istouch, presses)
		x,y = x/winxm,y/winym
		if inmenu then return end
		if selecting and x >= 175 and x <= 175+60 and y >= 25+75*(winxm/winym) and y <= 25+75*(winxm/winym)+60*(winxm/winym) then
			Cut()
		end
	end)
	KPressOperation:Override("KeyBind::CTRL+X", function(key, scancode, isrepeat)
		if typing then return end
		if key == "x" and (love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui")) then
			Cut()
		end
	end)
	DrawOperation:Override("PasteGraphics", function()
		if pasting then
			local ContainsVisibleTiles = false
			for y=0,#copied do
				for x=0,#copied[0] do
					if (copied[y][x].place) and (copied[y][x].ctype ~= c) then
						ContainsVisibleTiles = true
						break
					end
				end
				if ContainsVisibleTiles then break end
			end
			for y=0,#copied do
				for x=0,#copied[0] do
					if (copied[y][x].ctype ~= c) or (not ContainsVisibleTiles) then
						if copied[y][x].place then love.graphics.draw(tex[-2],math.floor((math.floor((love.mouse.getX()+offx)/zoom)+x)*zoom-offx+zoom/2),math.floor((math.floor((love.mouse.getY()+offy)/zoom)+y)*zoom-offy+zoom/2),0,zoom/texsize[-2].w,zoom/texsize[-2].h,texsize[-2].w2,texsize[-2].h2) end
						love.graphics.draw((tex[copied[y][x].ctype] or tex.nonexistant),(math.floor((love.mouse.getX()+offx)/zoom)+x)*zoom-offx+zoom/2,(math.floor((love.mouse.getY()+offy)/zoom)+y)*zoom-offy+zoom/2,copied[y][x].rot*math.pi/2,zoom/(texsize[copied[y][x].ctype] or texsize["nonexistant"]).w,zoom/(texsize[copied[y][x].ctype] or texsize["nonexistant"]).h,(texsize[copied[y][x].ctype] or texsize["nonexistant"]).w2,(texsize[copied[y][x].ctype] or texsize["nonexistant"]).h2)
					end
				end
			end
			love.graphics.rectangle("line",math.floor((math.floor((love.mouse.getX()+offx)/zoom))*zoom-offx),math.floor((math.floor((love.mouse.getY()+offy)/zoom))*zoom-offy),(#copied[0]+1)*zoom,(#copied+1)*zoom)
		end
	end)

	-- Dictionary
	if EdTweaks then
		EdTweaks:GetCategory"Base"
			:AddItem("ETw Cloak", "Makes nearby bordered ghost tiles invisible, and makes BG tiles invisible. This tile is invisible.")
			:SetAlias"Cloak Cell"
	end
end
