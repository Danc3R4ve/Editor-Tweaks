return function(api)
	EdTweaks = setmetatable(api,{})
	api.htext = {
		["Fill"] = "Fills an area with a specified cell.";
		["Free Draw"] = "Free draws an unlimited number of cells with no particular alignment.";
		["Line Draw"] = "Draws cells from one point to another.";
		["Square Draw"] = "Draws a square from one point to another.";
		["Circle Draw"] = "Draws a circle from one point to another.";
	}
	local round = function( x ) return math.floor( x + 0.5 ) end
	function api.EdTweaksButton(label, x,y, icon, shortcuts, descriptionoverride, noclose)
		--/ Create an Editor Tweaks button
		local Button = label
		local w,h = icon:getWidth(), icon:getHeight()
		local FadeSpeed = 3
		local w2,h2 = w/2, h/2

		local ButtonO = setmetatable({
			P = {x=x;y=y;}; -- Position
			S = {x=w;y=h;}; -- Size
			S2 = {x=w2;y=h2;}; -- Half size
			SC = 1; -- Scale
			C = {r=255;g=255;b=255;}; -- Color
			T = {r=255;g=255;b=255;}; -- Tint
			A = 1; -- Alpha
			Button = Button; -- Label (For bindings)

			Connected = {};
			Rescale = function(self, scale)
				assert(self.Button, "Object no longer exists.")
				assert(scale and tonumber(scale) and scale>=0, "Invalid scale used for resizing icon, must be greater than 0")
				self.SC = scale
				local S = self.S
				local S2 = self.S2
				S.x, S.y = round(scale * w), round(scale * h)
				S2.x, S2.y = round(scale * w2), round(scale * h2)
				return self
			end;
			Move = function(self, x,y)
				assert(self.Button, "Object no longer exists.")
				self.P.x, self.P.y = x, y
				return self
			end;
			Recolor = function(self, r,g,b)
				assert(self.Button, "Object no longer exists.")
				self.T.r, self.T.g, self.T.b = r, g, b
				return self
			end;
			Hitbox = function(self)
				assert(self.Button, "Object no longer exists.")
				local P,S,SC = self.P,self.S,self.SC
				return P.x, P.y, P.x+S.x, P.y+S.y
			end;
			Remove = function(self)
				assert(self.Button, "Object no longer exists.")
				DrawOperation:Unbind("DrawButton::" ..self.Button)
				UpdateOperation:Unbind("UpdateButton::" ..self.Button)
				KPressOperation:Unbind("Shortcuts::" ..self.Button)
				for Name,FnData in pairs(self.Connected) do
					if FnData.Binding and FnData.OpTable:FindBindByLabel(FnData.Binding.label) then
						FnData.OpTable:Unbind(FnData.Binding.label)
					end
				end
				self.Button = nil
			end;
			Click = function(self, ...)
				if self.OnClick then
					self.OnClick.Binding.f(...)
				end
				return self
			end;
			ChangeIcon = function(self, icon2)
				icon = icon2
				return self
			end;
			ConnectEvent = function(self, EName, EFn)
				assert(self.Button, "Object no longer exists.")
				if EName:lower() == "mpress" then
					assert((self.OnClick == nil), "This object already has an OnClick event.")
					self.OnClick = {
						OpTable = MPressOperation;
						Binding = MPressOperation:Bind("ButtonClick::" ..self.Button, function(x,y,b, istouch, presses)
							local x1,y1,x2,y2 = self:Hitbox()
							if x>=x1 and x<=x2 and y>=y1 and y<=y2 then
								placecells = false
								EFn(x,y,b, istouch, presses)
							end
						end);
					}
					table.insert(self.Connected, self.OnClick)
				end
			end;
		},{

		})

		do
			--/ Internal draw ops
			local _hi,_dt = false,0
			DrawOperation:Bind("DrawButton::" ..label, function()
				local C,T,P = ButtonO.C,ButtonO.T,ButtonO.P
				local TR,TG,TB = T.r/255, T.g/255, T.b/255
				local htext = label:match"^(.+) Button$" or label
				love.graphics.setColor(C.r/255 * TR, C.g/255 * TG, C.b/255 * TB, ButtonO.A)
				love.graphics.draw(icon, ButtonO.P.x, ButtonO.P.y, 0, ButtonO.SC, ButtonO.SC, 0,0)
				if #shortcuts[1] <= 1 then
					love.graphics.setFont(api.Fonts.Sax20)
					love.graphics.setColor(0,0,0,math.min(1,2*ButtonO.A))
					love.graphics.printf(shortcuts[1], ButtonO.P.x+2, ButtonO.P.y+2, 99999, 'left', 0, 1,1)
					love.graphics.setColor(1,1,1,math.min(1,2*ButtonO.A))
					love.graphics.printf(shortcuts[1], ButtonO.P.x, ButtonO.P.y, 99999, 'left', 0, 1,1)
				end
				if ButtonO.A == 1 then
					api.tooltip.Draw(htext, descriptionoverride or api.htext[htext] or "Unknown", {x=200})
				end
			end)
			KPressOperation:Bind("Shortcuts::" ..label, function(key)
				for i = 1, #shortcuts do
					local k = shortcuts[i]
					if key == k then
						local mx,my = love.mouse.getX(), love.mouse.getY()
						ButtonO:Click(ButtonO.P.x,ButtonO.P.y, 1)
						if not noclose then
							api.delay(0.1, function()
								api.ToggleEnabledState()
							end)
						end
					end
				end
			end)
			UpdateOperation:Bind("UpdateButton::" ..label, function(dt)
				local C,P = ButtonO.C,ButtonO.P
				if _dt < (1/FadeSpeed) then
					-- Fading in
					local rate = (1/FadeSpeed)
					_dt = math.min(rate, _dt + (dt * FadeSpeed))

					local lx1,lx2 = x-32,x
					ButtonO.A = _dt/rate
					C.r, C.g, C.b = 255*(_dt/rate/2), 255*(_dt/rate/2), 255*(_dt/rate/2)

					P.x = lerp(lx1, lx2, _dt/rate)
				else
					-- Display Hitbox
					local mx,my = love.mouse.getX(),love.mouse.getY()
					local x1,y1,x2,y2 = ButtonO:Hitbox()
					local rate = (1/FadeSpeed)
					if mx>=x1 and mx<=x2 and my>=y1 and my<=y2 then
						_dt = math.min(rate * 2, _dt + (dt * FadeSpeed * 2))
					elseif _dt>rate then
						_dt = math.max(rate, _dt - (dt * FadeSpeed * 2))
					end
					local AnimDelta = 0.5 + (_dt / 2 / rate)

					ButtonO.A = _dt/rate/2
					C.r, C.g, C.b = 255*AnimDelta, 255*AnimDelta, 255*AnimDelta
				end
			end)
		end

		return ButtonO
	end
end
