local dir = "ModEngine/Mods/Editor Tweaks/EdTweaks/" -- editor tweaks asset folder location
local tooltip = {}

local textOverride = {}
function tooltip.assignOverride(textOriginal, textTransform)
	textOverride[textOriginal] = textTransform
end
local defaultFont = love.graphics.getFont()
local sax = love.graphics.newFont(dir.. "saxmono.ttf", 32)
local sax2 = love.graphics.newFont(dir.. "saxmono.ttf", 20)
local ttp1 = love.graphics.newText(sax, "Testing")
local ttp2 = love.graphics.newText(sax2, "Testing tooltip description of epic proportions")
love.graphics.setFont(defaultFont)
function tooltip.Draw(title, txt, settings)
	assert(title, "No title was sent to the tooltip Draw function!")
	-- set variables
	txt = textOverride[txt] or txt
	local col = love.graphics.setColor -- shorthand
	local maxWidth = 0 -- max width for description segments
	local nt = "" -- new text segment temporary var
	local t = {} -- segment array
	local w,h = 300,0 -- width and height, these get overriden so it doesnt matter past step one
	-- go through the text and add lines to the table, calculating for line breaks
	for i = 1, #txt do
		nt=nt..txt:sub(i,i)
		ttp1:set(nt)
		if (ttp1:getWidth() > w - 20) and (txt:sub(i,i)==" ") then
			table.insert(t, nt:sub(1,-2))
			nt = ""
		elseif (ttp1:getWidth() > w - 20) and (txt:sub(i,i)=="-") then
			table.insert(t, nt:sub(1,-1))
			nt = ""
		end
	end
	-- if nt is still a valid text, compound it at the end
	if #nt>0 then table.insert(t, nt) end
	-- for each text segment, calculate the maximum width
	for i,txt in ipairs(t) do
		ttp2:set(txt)
		maxWidth = math.max(maxWidth, ttp2:getWidth())
	end
	-- set some vars dood
	w, h = maxWidth, 32+((#t) * 20)
	ttp1:set(textOverride[title] or title)
	-- if the title's longer than all segments, make it the new max width
	w = math.max(w, ttp1:getWidth())
	-- do draw
	local x,y = (settings.x or love.mouse.getX()) + 32,math.min(love.graphics.getHeight()-12-h, settings.y or love.mouse.getY())
	col(0.5,0.6,1,.25)
	love.graphics.rectangle('fill', x-8,y-8, w+16,h+16)
	col(0,0,0,.5)
	love.graphics.rectangle('fill', x-4,y-4, w+8,h+8)
	col(1,1,1,1)
	love.graphics.draw(ttp1, x,y, r, sx, sy, ox, oy, kx, ky)
	for i,txt in ipairs(t) do
		ttp2:set(txt)
		-- note: it's 32 because the title takes up space, and h above has 32 added to it
		love.graphics.draw(ttp2, x,y + 32 + ((i-1)*20), r, sx, sy, ox, oy, kx, ky)
	end
end

return tooltip
