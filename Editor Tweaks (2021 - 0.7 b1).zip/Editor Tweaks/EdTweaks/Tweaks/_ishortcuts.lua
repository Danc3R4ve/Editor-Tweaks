return function(api)
	local _offx,_offy,_zoom
	KPressOperation:Override("KeyBind::Space", function(key, scancode, isrepeat)
		if typing then return end
		if key == 'space' then
			paused = not paused
			if not paused then
				_offx,_offy,_zoom = offx,offy,zoom
			end
			isinitial = false
			modsOnUnpause()
		end
	end)
	KPressOperation:Override("KeyBind::R", function(key, scancode, isrepeat)
		if typing then return end
		if key == 'r' then
			if love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui") then
				if newheight ~= height-2 or newwidth ~= width-2 then
					undocells = nil
				end
				for y=0,newheight+1 do
					initial[y] = initial[y] or {}
					cells[y] = {}
					placeables[y] = placeables[y] or {}
					if y%25 == 0 then chunks[math.floor(y/25)] = {} end
					for x=0,newwidth+1 do
						if x == 0 or x == newwidth+1 or y == 0 or y == newheight+1 then
							if border == 1 then
								initial[y][x] = {ctype = -1, rot = 0}
							elseif border == 2 then
								initial[y][x] = {ctype = 40, rot = 0}
							elseif border == 3 then
								initial[y][x] = {ctype = 11, rot = 0}
							elseif border == 4 then
								initial[y][x] = {ctype = 50, rot = 0}
							end
						elseif x >= width-1 or y >= height-1 then
							initial[y][x] = {ctype = 0, rot = 0}
						end
						cells[y][x] = {}
						placeables[y][x] = placeables[y][x] or false
						chunks[math.floor(y/25)][math.floor(x/25)] = {}
					end
				end
				height = newheight+2
				width = newwidth+2
				bgsprites = love.graphics.newSpriteBatch(tex[0])
				for y=0,height-1 do
					for x=0,width-1 do
						cells[y][x].ctype = initial[y][x].ctype
						cells[y][x].rot = initial[y][x].rot
						cells[y][x].lastvars = {x,y,cells[y][x].rot}
						cells[y][x].testvar = ""
						bgsprites:add((x-1)*20,(y-1)*20)
					end
				end
				paused = true
				isinitial = true
				subtick = subtick and 0
				if _offx then
					-- reset camera to default position
					offx,offy,zoom = _offx,_offy,_zoom
					-- remove the default position, so we do not do it again uselessly
					_offx,_offy,_zoom = nil, nil, nil
				end
				RefreshChunks()
				modsOnReset()
			end
		end
	end)

	KPressOperation:Override("KeyBind::Up", function(key, scancode, isrepeat)
		if typing then return end
		if api.enabled then return end
		if key == 'up' then
			if zoom < 160 then
				zoom = zoom*2
				offx = offx*2 + 400*winxm
				offy = offy*2 + 300*winym
			end
		end
	end)
	KPressOperation:Override("KeyBind::Down", function(key, scancode, isrepeat)
		if typing then return end
		if api.enabled then return end
		if key == 'down' then
			if zoom > 2 then
				offx = (offx-400*winxm)*0.5
				offy = (offy-300*winym)*0.5
				zoom = zoom*0.5
			end
		end
	end)
end
