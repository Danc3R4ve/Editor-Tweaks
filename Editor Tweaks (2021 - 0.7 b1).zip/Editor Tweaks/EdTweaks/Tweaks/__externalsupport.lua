-- this activates if Cel Mod Loader is not used and this mod is directly loaded.

local cellinit = false
return function(resetBGSprites, CloakID)
	-- override the base bindings to include cloak support
	EdTweaks.EditPlacement = function()
		UpdateOperation:Override("Controls::Placement", function(dt)
			if not inmenu then
				if love.mouse.isDown(1) and placecells then
					local x = love.mouse.getX()/winxm
					local y = love.mouse.getY()/winym
					-- looks like controls
					if x >= 755 and y >= 475-40*(winxm/winym) and x <= 795 and y <= 475 then
						offx = offx + 10*60*dt
					elseif x >= 715 and y >= 475-80*(winxm/winym) and x <= 755 and y <= 475-40*(winxm/winym) then
						offy = offy - 10*60*dt
					elseif x >= 715 and y >= 475 and x <= 755 and y <= 475+40*(winxm/winym) then
						offy = offy + 10*60*dt
					elseif x >= 675 and y >= 475-40*(winxm/winym) and x <= 715 and y <= 475 then
						offx = offx - 10*60*dt
					elseif selecting then
						selw = math.max(math.min(math.floor((love.mouse.getX()+offx)/zoom),width-2),selx) - selx + 1
						selh = math.max(math.min(math.floor((love.mouse.getY()+offy)/zoom),height-2),sely) - sely + 1
					elseif (EdTweaks.drawMode == 'line') or (EdTweaks.drawMode == 'circle') or (EdTweaks.drawMode == 'square') then
						local x = math.floor((love.mouse.getX()+offx)/zoom)
						local y = math.floor((love.mouse.getY()+offy)/zoom)
						if not EdTweaks.Anchor then
							EdTweaks.Anchor = {x=x;y=y;}
						end
					elseif EdTweaks.drawMode == 'free' then
						local x = math.floor((love.mouse.getX()+offx)/zoom)
						local y = math.floor((love.mouse.getY()+offy)/zoom)
						-- updated free placement with line interpolations, so there are no gaps in the drawing (99% of the time)
						if lmx and lmy and EdTweaks.Shadowing then
							EdTweaks.line( lmx,lmy, x,y, function(nlx,nly, draw_count)
								if (not cellinit) then
									cellinit = true
									resetBGSprites()
								end
								if (currentstate == CloakID) then
									EdTweaks.Cloak(nlx,nly)
								else
									EdTweaks.Uncloak(nlx,nly)
								end
								EdTweaks.Place(nlx,nly)
								return true
							end)
						elseif EdTweaks.Shadowing then
							if (not cellinit) then
								cellinit = true
								resetBGSprites()
							end
							if (currentstate == CloakID) then
								EdTweaks.Cloak(x,y)
							else
								EdTweaks.Uncloak(x,y)
							end
							EdTweaks.Place(x,y)
						end
						lmx, lmy = x, y
					end
				else
					EdTweaks.Anchor = nil
					lmx, lmy = nil, nil
				end
			else
				EdTweaks.Anchor = nil
				lmx, lmy = nil, nil
			end
		end)
		MPressOperation:Override("Controls::Placement-Start", function(x,y,b, istouch)
			lmx,lmy = nil,nil
			if not placecells then return end
			if not EdTweaks.Shadowing then return end
			if b~=1 then return end
			if not inmenu then
				local x = math.floor((x+offx)/zoom)
				local y = math.floor((y+offy)/zoom)
				if EdTweaks.drawMode == 'fill' then
					local fillTile = cells[y][x] -- for reference
					local fills = {[y]={[x]=true}} -- give us our initial fill
					EdTweaks.GetFills(x,y, fillTile, fills) -- populate the array with our new tiles
					for nlx = 1, width do
						for nly = 1, height do
							if fills[nly] and fills[nly][nlx] then -- if we can fill this tile
								if (not cellinit) then
									cellinit = true
									resetBGSprites()
								end
								if (currentstate == CloakID) then
									EdTweaks.Cloak(nlx,nly)
								else
									EdTweaks.Uncloak(nlx,nly)
								end
								EdTweaks.Place(nlx,nly) -- do eet
							end
						end
					end
				end
			end
		end)
		MReleaseOperation:Override("Controls::Placement-End", function(x,y,b, istouch)
			if not placecells then return end
			if not inmenu then
				local x = math.floor((x+offx)/zoom)
				local y = math.floor((y+offy)/zoom)
				if EdTweaks.drawMode == 'line' then
					if EdTweaks.Anchor and EdTweaks.Shadowing then
						local ax,ay = EdTweaks.Anchor.x, EdTweaks.Anchor.y
						EdTweaks.line( ax,ay, x,y, function(nlx,nly, draw_count)
							if (not cellinit) then
								cellinit = true
								resetBGSprites()
							end
							if (currentstate == CloakID) then
								EdTweaks.Cloak(nlx,nly)
							else
								EdTweaks.Uncloak(nlx,nly)
							end
							EdTweaks.Place(nlx,nly)
							return true
						end)
						EdTweaks.Anchor = nil
					end
				elseif EdTweaks.drawMode == 'square' then
					if EdTweaks.Anchor and EdTweaks.Shadowing then
						local ax,ay = EdTweaks.Anchor.x, EdTweaks.Anchor.y
						local x1,y1,x2,y2 = math.min(ax,x),math.min(ay,y),math.max(ax,x),math.max(ay,y)
						if EdTweaks.drawConfig.isFilled then
							for nlx = x1, x2 do
								for nly = y1, y2 do
									if (not cellinit) then
										cellinit = true
										resetBGSprites()
									end
									if (currentstate == CloakID) then
										EdTweaks.Cloak(nlx,nly)
									else
										EdTweaks.Uncloak(nlx,nly)
									end
									EdTweaks.Place(nlx,nly)
								end
							end
						else
							for nlx = x1, x2 do
								for nly = y1, y2 do
									if nlx == x1 or nlx == x2 or nly == y1 or nly == y2 then
										if (not cellinit) then
											cellinit = true
											resetBGSprites()
										end
										if (currentstate == CloakID) then
											EdTweaks.Cloak(nlx,nly)
										else
											EdTweaks.Uncloak(nlx,nly)
										end
										EdTweaks.Place(nlx,nly)
									end
								end
							end
						end
						EdTweaks.Anchor = nil
					end
				elseif EdTweaks.drawMode == 'circle' then
					if EdTweaks.Anchor and EdTweaks.Shadowing then
						local ax,ay = EdTweaks.Anchor.x, EdTweaks.Anchor.y
						local x1,y1,x2,y2 = math.min(ax,x),math.min(ay,y),math.max(ax,x),math.max(ay,y) -- get min / max coords for absolute rendering
						for nlx = x1, x2 do
							local xs = (nlx - x1) / math.max(1, x2 - x1) -- get x ratio (0 - 1) with quick maths
							for nly = y1, y2 do
								local ys = (nly - y1) / math.max(1, y2 - y1) -- same for the y ratio, 0 - 1
								local n = ((xs - 0.5) ^ 2) + ((ys - 0.5) ^ 2)
								if EdTweaks.drawConfig.isFilled and (n <= 0.51 ^ 2) or -- if is in range
									(x2-x1<1) or (y2-y1<1) then -- or is a straight line
									if (not cellinit) then
										cellinit = true
										resetBGSprites()
									end
									if (currentstate == CloakID) then
										EdTweaks.Cloak(nlx,nly)
									else
										EdTweaks.Uncloak(nlx,nly)
									end
									EdTweaks.Place(nlx,nly) -- then place at the tile
								elseif (not EdTweaks.drawConfig.isFilled) and ((n >= 0.4 ^ 2) and (n <= 0.51 ^ 2)) or -- if is in range
									(x2-x1<1) or (y2-y1<1) then -- or is a straight line
									if (not cellinit) then
										cellinit = true
										resetBGSprites()
									end
									if (currentstate == CloakID) then
										EdTweaks.Cloak(nlx,nly)
									else
										EdTweaks.Uncloak(nlx,nly)
									end
									EdTweaks.Place(nlx,nly) -- then place at the tile
								end
							end
						end
						EdTweaks.Anchor = nil
					end
				end
			end
		end)
		UpdateOperation:Override("Controls::Deleting", function(dt)
			if not inmenu then
				if love.mouse.isDown(2) and placecells then
					selw = 0
					selh = 0
					local x = math.floor((love.mouse.getX()+offx)/zoom)
					local y = math.floor((love.mouse.getY()+offy)/zoom)
					if x > 0 and y > 0 and x < width-1 and y < height-1 then
						if not undocells then
							undocells = {}
							for y=0,height-1 do
								undocells[y] = {}
								for x=0,width-1 do
									undocells[y][x] = {}
									undocells[y][x].ctype = cells[y][x].ctype
									undocells[y][x].rot = cells[y][x].rot
									undocells[y][x].place = placeables[y][x]
									wasinitial = isinitial
								end
							end
						end
						if currentstate == -2 then
							if isinitial then
								placeables[y][x] = false
							end
						else
							EdTweaks.Uncloak(x,y)
							local original = CopyCell(x, y)
							cells[y][x].ctype = 0
							cells[y][x].rot = 0
							local originalInitial = CopyTable(cells[y][x])
							if isinitial then
								initial[y][x].ctype = 0
								initial[y][x].rot = 0
							end
							SetChunk(x,y,currentstate)
							modsOnPlace(0, x, y, 0, original, originalInitial)
						end
					end
				end
			end
		end)
	end
end
