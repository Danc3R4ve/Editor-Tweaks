

DrawOperation:Bind("PreDraw", function()
	love.graphics.setColor(1/8,1/8,1/8)
	love.graphics.rectangle("fill",-10,-10,9999,9999)
	love.graphics.setColor(1,1,1)
end)
DrawOperation:Bind("BG", function()
	love.graphics.draw(bgsprites,math.floor(zoom-offx+zoom/2),math.floor(zoom-offy+zoom/2),0,zoom/texsize[-1].w,zoom/texsize[-1].h,texsize[-1].w2,texsize[-1].h2)
end)
DrawOperation:Bind("TileBG", function()
	if currentstate ~= -2 then
		for y=math.max(math.floor(offy/zoom)-1,0),math.min(math.floor((offy+600*winym)/zoom)+1,height-1) do
			for x=math.max(math.floor(offx/zoom)-1,0),math.min(math.floor((offx+800*winxm)/zoom)+1,width-1) do
				if placeables[y][x] then
					love.graphics.draw(tex[-2],math.floor(x*zoom-offx+zoom/2),math.floor(y*zoom-offy+zoom/2),0,zoom/texsize[-2].w,zoom/texsize[-2].h,texsize[-2].w2,texsize[-2].h2)
				end
			end
		end
	end
end)
DrawOperation:Bind("Tile", function()
	for y=math.max(math.floor(offy/zoom)-1,0),math.min(math.floor((offy+600*winym)/zoom)+1,height-1) do
		for x=math.max(math.floor(offx/zoom)-1,0),math.min(math.floor((offx+800*winxm)/zoom)+1,width-1) do
			if cells[y][x].ctype ~= 0 then
				love.graphics.draw((tex[cells[y][x].ctype] or tex.nonexistant),math.floor(lerp(cells[y][x].lastvars[1],x,itime/delay)*zoom-offx+zoom/2),math.floor(lerp(cells[y][x].lastvars[2],y,itime/delay)*zoom-offy+zoom/2),lerp(cells[y][x].lastvars[3],cells[y][x].lastvars[3]+((cells[y][x].rot-cells[y][x].lastvars[3]+2)%4-2),itime/delay)*math.pi/2,zoom/(texsize[cells[y][x].ctype] or texsize["nonexistant"]).w,zoom/(texsize[cells[y][x].ctype] or texsize["nonexistant"]).h,(texsize[cells[y][x].ctype] or texsize["nonexistant"]).w2,(texsize[cells[y][x].ctype] or texsize["nonexistant"]).h2)
			end
			if dodebug then
				love.graphics.print(tostring(cells[y][x].testvar),x*zoom-offx+zoom/2,y*zoom-offy+zoom/2)
			end
			modsOnCellDraw(cells[y][x].ctype, x, y, cells[y][x].rot)
		end
	end
end)
DrawOperation:Bind("PlacableReset", function()
	if currentstate == -2 then
		for y=math.max(math.floor(offy/zoom)-1,0),math.min(math.floor((offy+600*winym)/zoom)+1,height-1) do
			for x=math.max(math.floor(offx/zoom)-1,0),math.min(math.floor((offx+800*winxm)/zoom)+1,width-1) do
				if placeables[y][x] then
					love.graphics.draw(tex[-2],math.floor(x*zoom-offx+zoom/2),math.floor(y*zoom-offy+zoom/2),0,zoom/texsize[-2].w,zoom/texsize[-2].h,texsize[-2].w2,texsize[-2].h2)
				end
			end
		end
	end
end)
DrawOperation:Bind("SelectionSquare", function()
	love.graphics.setColor(1,1,1,0.25)
	if selecting then
		love.graphics.rectangle("fill",math.floor((selx)*zoom-offx),math.floor((sely)*zoom-offy),selw*zoom,selh*zoom)
	end
end)
DrawOperation:Bind("SelectionSquare", function()
	love.graphics.setColor(1,1,1,0.5)
	if interpolate then
		love.graphics.draw(enemyparticles,-offx+zoom/2,-offy+zoom/2,0,zoom/20,zoom/20)
	end --interpolate is the variable name for all fancy graphics now. no, im not changing it, i'm too lazy
end)
DrawOperation:Bind("PasteGraphics", function()
	if pasting then
		for y=0,#copied do
			for x=0,#copied[0] do
				if copied[y][x].place then love.graphics.draw(tex[-2],math.floor((math.floor((love.mouse.getX()+offx)/zoom)+x)*zoom-offx+zoom/2),math.floor((math.floor((love.mouse.getY()+offy)/zoom)+y)*zoom-offy+zoom/2),0,zoom/texsize[-2].w,zoom/texsize[-2].h,texsize[-2].w2,texsize[-2].h2) end
				love.graphics.draw((tex[copied[y][x].ctype] or tex.nonexistant),(math.floor((love.mouse.getX()+offx)/zoom)+x)*zoom-offx+zoom/2,(math.floor((love.mouse.getY()+offy)/zoom)+y)*zoom-offy+zoom/2,copied[y][x].rot*math.pi/2,zoom/(texsize[copied[y][x].ctype] or texsize["nonexistant"]).w,zoom/(texsize[copied[y][x].ctype] or texsize["nonexistant"]).h,(texsize[copied[y][x].ctype] or texsize["nonexistant"]).w2,(texsize[copied[y][x].ctype] or texsize["nonexistant"]).h2)
			end
		end
		love.graphics.rectangle("line",math.floor((math.floor((love.mouse.getX()+offx)/zoom))*zoom-offx),math.floor((math.floor((love.mouse.getY()+offy)/zoom))*zoom-offy),(#copied[0]+1)*zoom,(#copied+1)*zoom)
	end
end)
DrawOperation:Bind("Debug-1", function()
	if dodebug then
		for y=0,(height-1)/25 do
			for x=0,(width-1)/25 do
				if ticknum == 0 then
					love.graphics.setColor(1,0,0)
				else
					love.graphics.setColor(1,1,1)
				end
				love.graphics.line(math.floor(x*25*zoom-offx),math.floor(y*25*zoom-offy),math.floor((x+1)*25*zoom-offx),math.floor((y)*25*zoom-offy))
				love.graphics.line(math.floor(x*25*zoom-offx),math.floor(y*25*zoom-offy),math.floor((x)*25*zoom-offx),math.floor((y+1)*25*zoom-offy))
			end
		end
		love.graphics.setColor(1,1,1)
	end
end)
DrawOperation:Bind("Toolbar", function()
	for i=0,15 do
		if listorder[i+16*(page-1)+1] then
			if currentstate == listorder[i+16*(page-1)+1] then love.graphics.setColor(1,1,1,1) else love.graphics.setColor(1,1,1,0.5) end
			love.graphics.draw(tex[listorder[i+16*(page-1)+1]],(25+(775-25)*i/15)*winxm,575*winym,currentrot*math.pi/2,40*winxm/texsize[listorder[i+16*(page-1)+1]].w,40*winxm/texsize[listorder[i+16*(page-1)+1]].h,texsize[listorder[i+16*(page-1)+1]].w2,texsize[listorder[i+16*(page-1)+1]].h2)
		end
	end
end)
DrawOperation:Bind("Buttons::Pause", function()
	if paused then
		love.graphics.setColor(0.5,0.5,0.5,0.75)
		love.graphics.setColor(1,1,1,0.5)
		love.graphics.draw(tex[1],725*winxm,25*winym,0,60*winxm/texsize[1].w,60*winxm/texsize[1].h)
	else
		love.graphics.setColor(1,1,1,0.5)
		love.graphics.draw(tex[4],785*winxm,25*winym,math.pi/2,60*winxm/texsize[4].w,60*winxm/texsize[4].h)
	end
end)
DrawOperation:Bind("Buttons::Undo", function()
	if undocells then love.graphics.draw(tex[27],725*winxm-150*winxm,25*winym,math.pi,60*winxm/texsize[27].w,60*winxm/texsize[27].h,texsize[27].w,texsize[27].h) end
end)
DrawOperation:Bind("Buttons::Advance_Step", function()
	love.graphics.draw(tex[16],725*winxm-75*winxm,25*winym,0,60*winxm/texsize[16].w,60*winxm/texsize[16].h)
end)
DrawOperation:Bind("Buttons::Menu", function()
	love.graphics.draw(tex.menu,25*winxm,25*winym,0,60*winxm/texsize.menu.w,60*winxm/texsize.menu.h)
end)
DrawOperation:Bind("Buttons::ZoomIn", function()
	love.graphics.draw(tex.zoomin,100*winxm,25*winym,0,60*winxm/texsize.zoomin.w,60*winxm/texsize.zoomin.h)
end)
DrawOperation:Bind("Buttons::ZoomOut", function()
	love.graphics.draw(tex.zoomout,175*winxm,25*winym,0,60*winxm/texsize.zoomout.w,60*winxm/texsize.zoomout.h)
end)
DrawOperation:Bind("Buttons::Clipboard-1", function()
	if selecting then
		love.graphics.draw(tex.copy,100*winxm,25*winym+75*winxm,0,60*winxm/texsize.copy.w,60*winxm/texsize.copy.h)
		love.graphics.draw(tex.cut,175*winxm,25*winym+75*winxm,0,60*winxm/texsize.cut.w,60*winxm/texsize.cut.h)
		love.graphics.setColor(1,1,1,0.75)
	end
end)
DrawOperation:Bind("Buttons::Select", function()
	love.graphics.draw(tex.select,25*winxm,25*winym+75*winxm,0,60*winxm/texsize.select.w,60*winxm/texsize.select.h)
end)
DrawOperation:Bind("Buttons::Clipboard-2", function()
	love.graphics.setColor(1,1,1,0.5)
	if copied then
		love.graphics.draw(tex.paste,25*winxm,25*winym+150*winxm,0,60*winxm/texsize.paste.w,60*winxm/texsize.paste.h)
		love.graphics.draw(tex[14],100*winxm,25*winym+150*winxm,0,60*winxm/texsize[14].w,60*winxm/texsize[14].h)
		love.graphics.draw(tex[14],235*winxm,25*winym+150*winxm,math.pi/2,60*winxm/texsize[14].w,60*winxm/texsize[14].h)
	end
end)
DrawOperation:Bind("Buttons::Controls", function()
	love.graphics.draw(tex[13],715*winxm,475*winym-80*winxm,-math.pi/2,40*winxm/texsize[13].w,40*winxm/texsize[13].h,texsize[13].w)
	love.graphics.draw(tex[13],755*winxm,475*winym-40*winxm,0,40*winxm/texsize[13].w,40*winxm/texsize[13].h)
	love.graphics.draw(tex[13],715*winxm,475*winym,math.pi/2,40*winxm/texsize[13].w,40*winxm/texsize[13].h,0,texsize[13].h)
	love.graphics.draw(tex[13],675*winxm,475*winym-40*winxm,math.pi,40*winxm/texsize[13].w,40*winxm/texsize[13].h,texsize[13].w,texsize[13].h)
	love.graphics.draw(tex[9],755*winxm,475*winym-80*winxm,0,40*winxm/texsize[9].w,40*winxm/texsize[9].h)
	love.graphics.draw(tex[8],675*winxm,475*winym-80*winxm,0,40*winxm/texsize[8].w,40*winxm/texsize[8].h)
	love.graphics.draw(tex[1],755*winxm,475*winym,0,40*winxm/texsize[1].w,40*winxm/texsize[1].h)
	love.graphics.draw(tex[1],675*winxm,475*winym,math.pi,40*winxm/texsize[1].w,40*winxm/texsize[1].h,texsize[1].w,texsize[1].h)
end)
DrawOperation:Bind("Buttons::Select", function()
	if not isinitial then
		love.graphics.draw(tex[10],725*winxm,25*winym+75*winxm,0,60*winxm/texsize[10].w,60*winxm/texsize[10].h)
		love.graphics.draw(tex.setinitial,725*winxm-150*winxm,25*winym+75*winxm,0,135*winxm/texsize.setinitial.w,60*winxm/texsize.setinitial.h)
	end
end)
local defaultFont = love.graphics.getFont()
DrawOperation:Bind("Menu", function()
	local x = love.mouse.getX()/winxm
	local y = love.mouse.getY()/winym
	if inmenu then
		love.graphics.setFont(defaultFont)
		love.graphics.setColor(0.5,0.5,0.5,0.5)
		love.graphics.rectangle("fill",100*winxm,75*winym,600*winxm,450*winym)
		love.graphics.setColor(1,1,1,1)
		love.graphics.print("this is the menu",300*winxm,120*winym,0,2*winxm,2*winym)
		love.graphics.print("CelLuAPI by IonutDoesStuffYT#1595",300*winxm,90*winym,0,winxm,winym)
		love.graphics.print("built on CelLua by KyYay",335*winxm,105*winym,0,winxm,winym)
		love.graphics.print("Update delay: "..string.sub(delay,1,4).."s",150*winxm,145*winym,0,winxm,winym)
		love.graphics.print("Ticks per update: "..tpu,150*winxm,180*winym,0,winxm,winym)
		love.graphics.print("Volume: "..volume*100 .."%",150*winxm,215*winym,0,winxm,winym)
		love.graphics.print("Border mode: "..border,150*winxm,250*winym,0,winxm,winym)
		love.graphics.print("Width (upon reset/clear)",225*winxm,305*winym,0,winxm,winym)
		love.graphics.print("Height (upon reset/clear)",425*winxm,305*winym,0,winxm,winym)
		love.graphics.print("Debug (Can cause lag!)",200*winxm,378*winym,0,winxm,winym)
		love.graphics.print("Fancy Graphix",400*winxm,378*winym,0,winxm,winym)
		love.graphics.print("Subticking",550*winxm,378*winym,0,winxm,winym)
		local modsString = "Running mods: "
		for i=1,#mods,1 do
			modsString = modsString .. mods[i] .. " "
		end
		if #mods> 0 then
			love.graphics.print(modsString,100*winxm,510*winym,0,winxm,winym)
		end
		love.graphics.setColor(1/4,1/4,1/4,1)
		love.graphics.rectangle("fill",150*winxm,160*winym,500*winxm,10*winym)
		love.graphics.rectangle("fill",150*winxm,195*winym,500*winxm,10*winym)
		love.graphics.rectangle("fill",150*winxm,230*winym,500*winxm,10*winym)
		love.graphics.rectangle("fill",150*winxm,265*winym,500*winxm,10*winym)
		love.graphics.rectangle("fill",250*winxm,325*winym,100*winxm,25*winym)
		love.graphics.rectangle("fill",450*winxm,325*winym,100*winxm,25*winym)
		love.graphics.rectangle("fill",175*winxm,375*winym,20*winxm,20*winym)
		love.graphics.rectangle("fill",375*winxm,375*winym,20*winxm,20*winym)
		love.graphics.rectangle("fill",525*winxm,375*winym,20*winxm,20*winym)
		love.graphics.setColor(1/2,1/2,1/2,1)
		love.graphics.rectangle("fill",lerp(149,649,delay,true)*winxm,160*winym,2*winxm,10*winym)
		love.graphics.rectangle("fill",lerp(149,649,(tpu-1)/9,true)*winxm,195*winym,2*winxm,10*winym)
		love.graphics.rectangle("fill",lerp(149,649,volume,true)*winxm,230*winym,2*winxm,10*winym)
		love.graphics.rectangle("fill",lerp(149,649,(border-1)/((#walls)-1),true)*winxm,265*winym,2*winxm,10*winym)
		if dodebug then
		love.graphics.polygon("fill",{180*winxm,378*winym ,177*winxm,380*winym ,190*winxm,393*winym ,193*winxm,390*winym})
		love.graphics.polygon("fill",{190*winxm,378*winym ,193*winxm,380*winym ,180*winxm,393*winym ,177*winxm,390*winym}) end
		if interpolate then
		love.graphics.polygon("fill",{380*winxm,378*winym ,377*winxm,380*winym ,390*winxm,393*winym ,393*winxm,390*winym})
		love.graphics.polygon("fill",{390*winxm,378*winym ,393*winxm,380*winym ,380*winxm,393*winym ,377*winxm,390*winym}) end
		if subtick then
		love.graphics.polygon("fill",{530*winxm,378*winym ,527*winxm,380*winym ,540*winxm,393*winym ,543*winxm,390*winym})
		love.graphics.polygon("fill",{540*winxm,378*winym ,543*winxm,380*winym ,530*winxm,393*winym ,527*winxm,390*winym}) end
		--if dodebug then love.graphics.polygon("fill",{267,385 ,264,382 ,258,394 ,255,391}) end
		love.graphics.setColor(1,1,1,1)
		if typing == 1 then love.graphics.print(newwidth.."_",255*winxm,330*winym,0,winxm,winym) else love.graphics.print(newwidth,255*winxm,330*winym,0,winxm,winym) end
		if typing == 2 then love.graphics.print(newheight.."_",455*winxm,330*winym,0,winxm,winym) else love.graphics.print(newheight,455*winxm,330*winym,0,winxm,winym) end
		if x > 170 and y > 420 and x < 230 and y < 480 then love.graphics.setColor(1,1,1,0.75) love.graphics.print("Close menu\n     (Esc)",165*winxm,480*winym,0,winxm,winym) else love.graphics.setColor(1,1,1,0.5) end
		love.graphics.draw(tex[1],200*winxm,450*winym,0,60*winxm/texsize[1].w,60*winym/texsize[1].h,texsize[1].w2,texsize[1].h2)
		if x > 270 and y > 420 and x < 330 and y < 480 then love.graphics.setColor(1,1,1,0.75) love.graphics.print("Restart level\n   (Ctrl+R)",265*winxm,480*winym,0,winxm,winym) else love.graphics.setColor(1,1,1,0.5) end
		love.graphics.draw(tex[10],300*winxm,450*winym,0,60*winxm/texsize[10].w,60*winym/texsize[10].h,texsize[10].w2,texsize[10].h2)
		if x > 370 and y > 420 and x < 430 and y < 480 then love.graphics.setColor(1,1,1,0.75) love.graphics.print("Clear level",369*winxm,480*winym,0,winxm,winym) else love.graphics.setColor(1,1,1,0.5) end
		love.graphics.draw(tex[11],400*winxm,450*winym,0,60*winxm/texsize[11].w,60*winym/texsize[11].h,texsize[11].w2,texsize[11].h2)
		if x > 470 and y > 420 and x < 530 and y < 480 then love.graphics.setColor(1,1,1,0.75) love.graphics.print("Save level",470*winxm,480*winym,0,winxm,winym) else love.graphics.setColor(1,1,1,0.5) end
		love.graphics.draw(tex[2],500*winxm,450*winym,math.pi*1.5,60*winym/texsize[2].w,60*winxm/texsize[2].h,texsize[2].w2,texsize[2].h2)
		if x > 570 and y > 420 and x < 630 and y < 480 then love.graphics.setColor(1,1,1,0.75) love.graphics.print("Load level\n(V3/K1/K2)",570*winxm,480*winym,0,winxm,winym)  else love.graphics.setColor(1,1,1,0.5) end
		love.graphics.draw(tex[16],600*winxm,450*winym,math.pi*0.5,60*winym/texsize[16].w,60*winxm/texsize[16].h,texsize[16].w2,texsize[16].h2)
	end
end)
DrawOperation:Bind("InstructionsUI", function()
	if showinstructions then
		love.graphics.setColor(1,1,1,1)
		love.graphics.print("WASD = Move\n(Ctrl to speed up)\n\nQ/E = Rotate\n\nEsc = Menu\n\nZ/C = Change cell selection page\n\nSpace = Pause\n\nF = Advance one tick\n\nUp/down or mousewheel = Zoom in/out\n\nTab = Select\n\nOther shortcuts are obvious",10*winxm,300*winym,0,1*winxm,1*winym)
	end
end)
DrawOperation:Bind("FPSUI", function()
	love.graphics.setColor(1,1,1,0.5)
	love.graphics.print("FPS: ".. 1/delta,10,10)
end)
DrawOperation:Bind("VKeyboardUI", function()
	if typing then
		love.keyboard.setTextInput(true)
	else
		love.keyboard.setTextInput(false)
	end
end)
DrawOperation:Bind("CelLuaAPI_Base", function()
	modsCustomDraw()
end)

return {}
