-- functions set to change in tandem with their linked bindings, aka: if you disable one you can disable many
local dir = "ModEngine/Mods/Editor Tweaks/EdTweaks/Internal/" -- editor tweaks internals folder location
local api = {}

local Links = {}
local _require = require
local function require(name) return _require(dir .. name) end
local function __islinked(self, binding2) for obj,link in pairs(Links[self] or {}) do if link==binding2 then return true end end return false end
local function __link(self, binding2) Links[self] = Links[self] or {} table.insert(Links[self],binding2) Links[binding2] = Links[binding2] or {} table.insert(Links[binding2],self) return self end
local function __unbind(self, binding)
	local toUnbind
	for i,Bind in pairs(self.Bound) do
		if Bind.label == binding then
			toUnbind = Bind
			self.Bound[i] = nil
		end
	end
	if Links[toUnbind] then
		for i = #Links[toUnbind], 1, -1 do
			local Bind = Links[toUnbind][i]
			-- remove this link's references
			table.remove(Links[toUnbind], i)
			if Links[Bind] then
				for ii = #Links[Bind], 1, -1 do
					-- remove each reference to this binding in other links
					local Bind2 = Links[Bind][ii]
					if Bind2 == toUnbind then
						table.remove(Links[Bind], ii)
					end
				end
				if #Links[Bind] < 1 then
					Links[Bind] = nil
				end
			end
		end
		Links[toUnbind] = nil
	end
	return self
end
local function __enable(self)
	self.on=true
	if Links[self] then
		for _,Link in pairs(Links[self]) do
			Link.on = true
		end
	end
	return self
end
local function __disable(self)
	self.on=false
	if Links[self] then
		for _,Link in pairs(Links[self]) do
			Link.on = false
		end
	end
	return self
end
local function __rename(self,n)
	self.label=n
	if Links[self] then
		for _,Link in pairs(Links[self]) do
			Link.Label = n
		end
	end
	return self
end
local function __sort(self)
	for k,v in pairs(self.Bound) do
		assert(v and v.order, "Null value for key: " ..tostring(k))
	end
	table.sort(self.Bound, function(n1,n2)
		return n1 and n2 and n1.order<n2.order
	end)
	return self
end
local function __bind(self, label, Fn)
	local newbinding = {
		label=label,
		order=#self.Bound,
		f=Fn,
		on=true,
		Enable=__enable,
		Disable=__disable,
		Rename=__rename,
		Link=__link,
		IsLinked=__islinked
	}
	table.insert(self.Bound,newbinding)
	self:Sort()
	return newbinding
end
local function __find_order(self, order) for _,Binding in pairs(self.Bound) do if Binding.order==order then return Binding end end end
local function __find_label(self, name) for _,Binding in pairs(self.Bound) do if Binding.label==name then return Binding end end end
-- shorthand for Operation:FindBindByLabel(name).on
local function __ison(self, name) return self:FindBindByLabel(name).on end
local function __override_binding(self, name, Fn)
	for _,c in pairs(self.Bound) do
		if c.label == name then
			c.f = Fn
		end
	end
end
local function __extend_binding(self, name, Fn)
	for _,c in pairs(self.Bound) do
		if c.label == name then
			local oldfn = c.f
			c.f = function(...)
				oldfn(...)
				Fn(...)
			end
		end
	end
end

local function __CreateOperationTable()
	-- Creates an operation table in which can bind and unbind things among other things!
	return {
		Bound={};
		Sort=__sort;
		Bind=__bind;
		BindOrOverride=function(self, label, Fn) -- Overrides if it exists, binds otherwise
			if self:FindBindByLabel(label) then
				return self:Override(label, Fn)
			else
				return self:Bind(label, Fn)
			end
		end;
		Unbind=__unbind;
		IsOn=__ison;
		Override=__override_binding; -- Change the function out with another one
		Extend=__extend_binding; -- Wrap the function in another function, acting after the initial
		FindBindByOrder=__find_order; -- Find the binding which has the specified order
		FindBindByLabel=__find_label; -- Finds a binding by its label
		BindBefore=function(self, label, Fn)
			-- Find and bind to first applicable order before a label's binding
			local margin = 1/10000 -- how much to increment or decrement the order by
			local ordered = 0
			local Binding = assert( self:FindBindByLabel(label) , "Unable to bind before: Binding not found >> \""..tostring(label).."\"!")
			while self:FindBindByOrder(Binding.order + ordered) do
				ordered = ordered - margin
			end
			local b = self:Bind(label.. "|"..ordered, Fn)
			b.order = Binding.order + ordered
			return b
		end;
		BindAfter=function(self, label, Fn)
			-- Find and bind to first applicable order after a label's binding
			local margin = 1/10000 -- how much to increment or decrement the order by
			local ordered = 0
			local Binding = assert( self:FindBindByLabel(label) , "Unable to bind after: Binding not found >> \""..tostring(label).."\"!")
			while self:FindBindByOrder(Binding.order + ordered) do
				ordered = ordered + margin
			end
			local b = self:Bind(label.. "|"..ordered, Fn)
			b.order = Binding.order + ordered
			return b
		end;
	}
end

-- globals for use in other mods
DrawOperation = __CreateOperationTable()
UpdateOperation = __CreateOperationTable()
MPressOperation = __CreateOperationTable()
MReleaseOperation = __CreateOperationTable()
KPressOperation = __CreateOperationTable()
KReleaseOperation = __CreateOperationTable()

require'draw'
require'update'
require'mpress'
require'mrelease'
require'kpress'
require'krelease'

function api.DoOperationBindings(self)
	function love.draw()
		-- Draw things in the order they are requested
		for _,c in pairs(DrawOperation.Bound) do
			if c.on then c.f() end
		end
	end
	function love.keypressed(key, scancode, isrepeat)
		-- Mouse Press Operations
		for _,c in pairs(KPressOperation.Bound) do
			if c.on then c.f(key, scancode, isrepeat) end
		end
	end
	function love.keyreleased(key)
		-- Mouse Press Operations
		for _,c in pairs(KReleaseOperation.Bound) do
			if c.on then c.f(key) end
		end
	end
	function love.mousepressed(x,y,b, istouch, presses)
		-- Mouse Press Operations
		for _,c in pairs(MPressOperation.Bound) do
			if c.on then c.f(x,y,b, istouch, presses) end
		end
	end
	function love.mousereleased(x,y,b, istouch, presses)
		-- Mouse Release Operations
		for _,c in pairs(MReleaseOperation.Bound) do
			if c.on then c.f(x,y,b, istouch, presses) end
		end
	end
	function love.update(dt)
		-- Draw things in the order they are requested
		for _,c in pairs(UpdateOperation.Bound) do
			if c.on then c.f(dt) end
		end
	end
end
api:DoOperationBindings()

local function fb(optable, name)
	return optable:FindBindByLabel(name)
end
local function fbdraw(name)
	return DrawOperation:FindBindByLabel(name)
end

-- Link the events, so you can disable all related events at once
fbdraw("Buttons::Menu"):Link(fb(MPressOperation, "Hitbox::OpenMenu"))
fbdraw("Buttons::ZoomIn"):Link(fb(MPressOperation, "Hitbox::ZoomIn"))
fbdraw("Buttons::ZoomOut"):Link(fb(MPressOperation, "Hitbox::ZoomOut"))
fbdraw("Buttons::Select"):Link(fb(MPressOperation, "Hitbox::Select"))
--fbdraw("Buttons::Select"):Link(fb(MPressOperation, "Hitbox::Select"))
fbdraw("Toolbar")
	:Link(fb(MPressOperation, "Hitbox::TilePicker"))

fbdraw("Buttons::Menu"):Disable()
fbdraw("Buttons::ZoomIn"):Disable()
fbdraw("Buttons::ZoomOut"):Disable()
fbdraw("Buttons::Select"):Disable()
fbdraw("Toolbar"):Disable()

fbdraw("FPSUI"):Disable()

return api
