

KPressOperation:Bind("KeyBind::TextBox1", function(key, scancode, isrepeat)
	if typing == 1 then
		if tonumber(key) then
			newwidth = tonumber(string.sub(tostring(newwidth)..key,1,3))
		elseif key == "backspace" then
			newwidth = tonumber(string.sub(tostring(newwidth),1,string.len(tostring(newwidth))-1)) or 0
		end
	end
end)
KPressOperation:Bind("KeyBind::TextBox2", function(key, scancode, isrepeat)
	if typing == 2 then
		if tonumber(key) then
			newheight = tonumber(string.sub(tostring(newheight)..key,1,3))
		elseif key == "backspace" then
			newheight = tonumber(string.sub(tostring(newheight),1,string.len(tostring(newheight))-1)) or 0
		end
	end
end)

KPressOperation:Bind("KeyBind::Q", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'q' then
		if pasting then
			local lastcop = {}
			local selh = #copied
			local selw = #copied[0]
			for y=0,selh do
				lastcop[y] = {}
				for x=0,selw do
					lastcop[y][x] = {}
					lastcop[y][x].ctype = copied[y][x].ctype
					lastcop[y][x].rot = copied[y][x].rot
					lastcop[y][x].place = copied[y][x].place
				end
			end
			copied = {}
			for y=0,selw do
				copied[y] = {}
				for x=0,selh do
					copied[y][x] = {}
					copied[y][x].ctype = lastcop[x][selw-y].ctype
					copied[y][x].rot = (lastcop[x][selw-y].rot-1)%4
					copied[y][x].place = lastcop[x][selw-y].place
				end
			end
		else
			currentrot = (currentrot - 1)%4
		end
	end
end)
KPressOperation:Bind("KeyBind::E", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'e' then
		if pasting then
			local lastcop = {}
			local selh = #copied
			local selw = #copied[0]
			for y=0,selh do
				lastcop[y] = {}
				for x=0,selw do
					lastcop[y][x] = {}
					lastcop[y][x].ctype = copied[y][x].ctype
					lastcop[y][x].rot = copied[y][x].rot
					lastcop[y][x].place = copied[y][x].place
				end
			end
			copied = {}
			for y=0,selw do
				copied[y] = {}
				for x=0,selh do
					copied[y][x] = {}
					copied[y][x].ctype = lastcop[selh-x][y].ctype
					copied[y][x].rot = (lastcop[selh-x][y].rot+1)%4
					copied[y][x].place = lastcop[selh-x][y].place
				end
			end
		else
			currentrot = (currentrot + 1)%4
		end
	end
end)

KPressOperation:Bind("KeyBind::Up", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'up' then
		if zoom < 160 then
			zoom = zoom*2
			offx = offx*2 + 400*winxm
			offy = offy*2 + 300*winym
		end
	end
end)
KPressOperation:Bind("KeyBind::Down", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'down' then
		if zoom > 2 then
			offx = (offx-400*winxm)*0.5
			offy = (offy-300*winym)*0.5
			zoom = zoom*0.5
		end
	end
end)
KPressOperation:Bind("KeyBind::Space", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'space' then
		paused = not paused
		isinitial = false
		modsOnUnpause()
	end
end)
KPressOperation:Bind("KeyBind::F", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'f' then
		for y=0,height-1 do
			for x=0,width-1 do
				cells[y][x].lastvars = {x,y,cells[y][x].rot}
			end
		end
		DoTick()
		dtime = 0
		itime = 0
		isinitial = false
	end
end)
KPressOperation:Bind("KeyBind::Escape", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'escape' then
		inmenu = not inmenu
		showinstructions = false
		typing = false
	end
end)
KPressOperation:Bind("KeyBind::CTRL+R", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'r' then
		if love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui") then
			if newheight ~= height-2 or newwidth ~= width-2 then
				undocells = nil
			end
			for y=0,newheight+1 do
				initial[y] = initial[y] or {}
				cells[y] = {}
				placeables[y] = placeables[y] or {}
				if y%25 == 0 then chunks[math.floor(y/25)] = {} end
				for x=0,newwidth+1 do
					if x == 0 or x == newwidth+1 or y == 0 or y == newheight+1 then
						if border == 1 then
							initial[y][x] = {ctype = -1, rot = 0}
						elseif border == 2 then
							initial[y][x] = {ctype = 40, rot = 0}
						elseif border == 3 then
							initial[y][x] = {ctype = 11, rot = 0}
						elseif border == 4 then
							initial[y][x] = {ctype = 50, rot = 0}
						end
					elseif x >= width-1 or y >= height-1 then
						initial[y][x] = {ctype = 0, rot = 0}
					end
					cells[y][x] = {}
					placeables[y][x] = placeables[y][x] or false
					chunks[math.floor(y/25)][math.floor(x/25)] = {}
				end
			end
			height = newheight+2
			width = newwidth+2
			bgsprites = love.graphics.newSpriteBatch(tex[0])
			for y=0,height-1 do
				for x=0,width-1 do
					cells[y][x].ctype = initial[y][x].ctype
					cells[y][x].rot = initial[y][x].rot
					cells[y][x].lastvars = {x,y,cells[y][x].rot}
					cells[y][x].testvar = ""
					bgsprites:add((x-1)*20,(y-1)*20)
				end
			end
			paused = true
			isinitial = true
			subtick = subtick and 0
			RefreshChunks()
			modsOnReset()
		end
	end
end)
KPressOperation:Bind("KeyBind::Tab", function(key, scancode, isrepeat)
	if typing then return end
	if key == 'tab' then
		selecting = not selecting
		selw = 0
		selh = 0
	end
end)
KPressOperation:Bind("KeyBind::CTRL+C", function(key, scancode, isrepeat)
	if typing then return end
	if key == "c" and (love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui")) then
		if selecting and selh > 0 then
			copied = {}
			for y=0,selh-1 do
				copied[y] = {}
				for x=0,selw-1 do
					copied[y][x] = {}
					copied[y][x].ctype = cells[y+sely][x+selx].ctype
					copied[y][x].rot = cells[y+sely][x+selx].rot
					copied[y][x].place = placeables[y+sely][x+selx]
				end
			end
			selecting = false
		end
	end
end)
KPressOperation:Bind("KeyBind::CTRL+X", function(key, scancode, isrepeat)
	if typing then return end
	if key == "x" and (love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui")) then
		if selecting and selh > 0 then
			copied = {}
			for y=0,selh-1 do
				copied[y] = {}
				for x=0,selw-1 do
					copied[y][x] = {}
					copied[y][x].ctype = cells[y+sely][x+selx].ctype
					copied[y][x].rot = cells[y+sely][x+selx].rot
					copied[y][x].place = placeables[y+sely][x+selx]
					cells[y+sely][x+selx].ctype = 0
					cells[y+sely][x+selx].rot = 0
					if isinitial then
						initial[y+sely][x+selx].ctype = 0
						placeables[y+sely][x+selx] = false
					end
				end
			end
			selecting = false
		end
	end
end)
KPressOperation:Bind("KeyBind::CTRL+Z", function(key, scancode, isrepeat)
	if typing then return end
	if key == "z" and (love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui")) then
		if undocells then
			for y=0,height-1 do
				for x=0,width-1 do
					cells[y][x].ctype = undocells[y][x].ctype
					cells[y][x].rot = undocells[y][x].rot
					cells[y][x].lastvars = {x,y,undocells[y][x].rot}
					placeables[y][x] = undocells[y][x].place
					if wasinitial then
						initial[y][x].ctype = undocells[y][x].ctype
						initial[y][x].rot = undocells[y][x].rot
					end
				end
			end
			undocells = nil
		end
		RefreshChunks()
	end
end)
KPressOperation:Bind("KeyBind::CTRL+V", function(key, scancode, isrepeat)
	if typing then return end
	if key == "v" and (love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui")) and copied then
		selecting = false
		pasting = true
	end
end)
KPressOperation:Bind("KeyBind::C", function(key, scancode, isrepeat)
	if typing then return end
	if (love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui")) then return end
	if key == 'c' then
		page = math.min(page+1,math.ceil(#listorder/16))
		placecells = false
	end
end)
KPressOperation:Bind("KeyBind::Z", function(key, scancode, isrepeat)
	if typing then return end
	if (love.keyboard.isDown("lctrl") or love.keyboard.isDown("lgui")) then return end
	if key == 'z' then
		page = math.max(page-1,1)
		placecells = false
	end
end)
KPressOperation:Bind("ModCompat", function(key, scancode, isrepeat)
	modsOnKeyPressed(key, scancode, isrepeat)
end)
