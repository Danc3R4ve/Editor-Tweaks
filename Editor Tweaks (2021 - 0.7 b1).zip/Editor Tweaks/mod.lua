--[[ 0.7 b1
	- Changed the default grid size to 24x24
	- Added function to allow easily switching to a new empty grid
	- Fixed the menu's font not displaying properly
	- Added support for reading AP2 encoding (though it does not write to it)
	- Added support for ETW encoding (hold shift while pressing the save/load buttons!)
	- Removed the Page Left / Page Right buttons, as they were redundant
	- Pressing CTRL+P Will zoom your screen to match the size of the grid
	- Cursor ghost tiles no longer get rendered over cloaked tiles, for maximum immersion
	- Control location of UI moved further down
]]

local _dir = "ModEngine/Mods/Editor Tweaks/EdTweaks/" -- editor tweaks asset folder location
local _EditorButtonPath = _dir.. "Images/editor_button.png" -- path to the editor button bg
local Tweaks = _dir.. "Tweaks/" -- the tweaks directory
local api = {
	dir = _dir;
	Version = "2021 - 0.7 b1";
	Dependencies = {
		"version: 2021 - 0.4 b1"; -- engine version
	};
	EditorButtonPath = _EditorButtonPath;
	Assets = setmetatable({
		ico=love.image.newImageData("textures/freezer.png"); -- Icon of the game
		Button=love.graphics.newImage(_EditorButtonPath);
		--
		Free=love.graphics.newImage(_dir.. "Images/editor_freedraw.png");
		Line=love.graphics.newImage(_dir.. "Images/editor_linedraw.png");
		Circle=love.graphics.newImage(_dir.. "Images/editor_circledraw.png");
		Square=love.graphics.newImage(_dir.. "Images/editor_squaredraw.png");
		Fill=love.graphics.newImage(_dir.. "Images/editor_fill.png");
		Plus=love.graphics.newImage(_dir.. "Images/editor_plus.png");
		--
		Fuzzy=love.graphics.newImage(_dir.."Images/editor_l_fuzzy.png");
		Filled=love.graphics.newImage(_dir.."Images/editor_l_filled.png");
		Random=love.graphics.newImage(_dir.."Images/editor_l_random.png");
		RoundRobin=love.graphics.newImage(_dir.."Images/editor_l_roundrobin.png");
		Static=love.graphics.newImage(_dir.."Images/editor_l_static.png");
		--
		KBMode=love.graphics.newImage(_dir.."Images/editor_l_kbmode.png");
		Down=love.graphics.newImage(_dir.."Images/editor_l_kbdown.png");
		Up=love.graphics.newImage(_dir.."Images/editor_l_kbup.png");
		PageDown=love.graphics.newImage(_dir.."Images/editor_l_kbpagedown.png");
		PageUp=love.graphics.newImage(_dir.."Images/editor_l_kbpageup.png");
		Select=love.graphics.newImage(_dir.."Images/editor_l_kbselect.png");
		--
	}, {
		-- make editing the button or plus textures update the image bank
		__newindex = function(self, prop, val)
			rawset(self, prop, val)
			if prop == 'Button' or prop == 'Plus' then
				api.ImageBank[prop:lower()].image = val
			end
		end;
	});
}

api.tooltip = require(Tweaks.. "tooltip");
require(Tweaks.. "config")(api) -- variables for all later requirements
require(Tweaks.. "classes")(api) -- EdTweaks custom objects
require(Tweaks.. "apifunctions")(api) -- all of the EdTweaks API default functions before init
require(Tweaks.. "vanilladictionary")(api) -- the dictionary containing the game's menu information
require(Tweaks.. "wrappers")(api) -- functionality that involves extending existing functions, rather than overwriting
api.ExternalLoad = require(Tweaks.. "__externalsupport") -- its not activated unless needed later
require(Tweaks.. "newtiles")(api) -- edtweaks tiles
require(Tweaks.. "game")(api)
require(Tweaks.. "save")(api)

api.init = function(engine)
	require(Tweaks.. "_iconfig")(api) -- config that is refreshed on init
	require(Tweaks.. "_iclock")(api) -- refresh clock on init
	require(Tweaks.. "_itools")(api) -- init's util functions
	require(Tweaks.. "_ighosttiles")(api) -- init ghost tile code
	require(Tweaks.. "_imenu")(api) -- init menu code
	require(Tweaks.. "_ishortcuts")(api) -- init key binding operations
	require(Tweaks.. "_iplacement")(api) -- placement tweaks init
	if not Cel then
		EdTweaks.EditPlacement()
	end
	require(Tweaks.. "_idebug")(api) -- placement tweaks init
end

return api
